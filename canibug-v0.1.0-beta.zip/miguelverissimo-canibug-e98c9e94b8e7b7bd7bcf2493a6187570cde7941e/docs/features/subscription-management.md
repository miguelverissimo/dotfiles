# Subscription Management

## Overview

Subscription Management handles user subscriptions, payments, and access control using Stripe integration. It provides a seamless way for users to upgrade their accounts and manage their billing.

## Data Flow

```plantuml
@startuml Subscription Flow
!theme plain
skinparam linetype ortho

actor User
boundary "Subscription UI" as UI
control "Server Actions" as Actions
entity "Database" as DB
queue "Stripe" as StripeAPI

' Subscribe Flow
group New Subscription
    User -> UI: Click "Subscribe"
    UI -> Actions: createCheckoutSession()
    activate Actions
    Actions -> StripeAPI: Create Checkout Session
    StripeAPI --> Actions: Session URL
    Actions --> UI: Redirect URL
    deactivate Actions
    UI --> User: Redirect to Stripe
    
    User -> StripeAPI: Complete Payment
    StripeAPI -> Actions: Webhook (payment_success)
    activate Actions
    Actions -> DB: Update User Status
    DB --> Actions: Status Updated
    Actions --> StripeAPI: 200 OK
    deactivate Actions
end

' Update Subscription Flow
group Update Subscription
    User -> UI: Click "Manage Subscription"
    UI -> Actions: createBillingPortalSession()
    activate Actions
    Actions -> StripeAPI: Create Portal Session
    StripeAPI --> Actions: Portal URL
    Actions --> UI: Redirect URL
    deactivate Actions
    UI --> User: Redirect to Portal
    
    User -> StripeAPI: Update Subscription
    StripeAPI -> Actions: Webhook (subscription_updated)
    activate Actions
    Actions -> DB: Update Subscription
    DB --> Actions: Status Updated
    Actions --> StripeAPI: 200 OK
    deactivate Actions
end

' Cancel Subscription Flow
group Cancel Subscription
    User -> StripeAPI: Cancel in Portal
    StripeAPI -> Actions: Webhook (subscription_canceled)
    activate Actions
    Actions -> DB: Update Status
    DB --> Actions: Status Updated
    Actions --> StripeAPI: 200 OK
    deactivate Actions
end

@enduml
```

## Implementation Details

### Components

- `SubscriptionButton`: Client Component for initiating subscription
- `ManageSubscriptionButton`: Client Component for accessing billing portal
- `SubscriptionStatus`: Server Component for displaying current status
- `PricingPlans`: Server Component for displaying available plans

### Database Schema

```typescript
interface User {
  // ... other fields
  subscriptionStatus: SubscriptionStatus;
  customerId: string | null;
}

enum SubscriptionStatus {
  active = 'active',
  inactive = 'inactive'
}
```

### API Endpoints

#### Create Checkout Session
```typescript
POST /api/billing/checkout
{
  priceId: string;
  successUrl: string;
  cancelUrl: string;
}
```

#### Create Billing Portal Session
```typescript
GET /api/billing/billing-portal
```

#### Stripe Webhook Handler
```typescript
POST /api/billing/webhook
```

### Server Actions

```typescript
'use server'

async function createCheckoutSession(data: CreateCheckoutSessionSchema) {
  // Validate input
  // Create Stripe checkout session
  // Return redirect URL
}

async function createBillingPortalSession() {
  // Validate user
  // Create Stripe billing portal session
  // Return redirect URL
}

async function handleStripeWebhook(event: Stripe.Event) {
  // Validate webhook signature
  // Handle various event types
  // Update database accordingly
}
```

### Validation

```typescript
const createCheckoutSessionSchema = z.object({
  priceId: z.string().min(1),
  successUrl: z.string().url(),
  cancelUrl: z.string().url()
});
```

## Security

- Stripe webhook signature verification
- User authentication required
- HTTPS only endpoints
- Rate limiting on all endpoints
- Secure handling of customer data

## Error Handling

### Client-side
- Loading states during redirects
- Error messages for failed payments
- Retry mechanisms for failed requests
- Graceful degradation

### Server-side
- Webhook retry handling
- Transaction rollback
- Error logging and monitoring
- Proper HTTP status codes

## Performance

- Asynchronous webhook processing
- Proper database indexing
- Caching of subscription status
- Background job processing

## Testing

### Unit Tests
```typescript
describe('Subscription Management', () => {
  it('creates a checkout session', async () => {
    // Test implementation
  });

  it('creates a billing portal session', async () => {
    // Test implementation
  });

  it('handles webhook events correctly', async () => {
    // Test implementation
  });
});
```

### Integration Tests
- Stripe API integration
- Webhook handling
- Database updates
- Error scenarios

### E2E Tests
- Subscription flow
- Portal access
- Webhook processing
- Error handling

## Stripe Configuration

### Webhook Events
- `checkout.session.completed`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `invoice.payment_succeeded`
- `invoice.payment_failed`

### Products and Prices
```typescript
const STRIPE_PLANS = {
  BASIC: {
    priceId: 'price_xxx',
    features: ['Feature 1', 'Feature 2']
  },
  PRO: {
    priceId: 'price_yyy',
    features: ['Feature 1', 'Feature 2', 'Feature 3']
  }
} as const;
```

## Monitoring

- Stripe Dashboard integration
- Payment success/failure rates
- Subscription churn tracking
- Revenue metrics
- Error tracking 