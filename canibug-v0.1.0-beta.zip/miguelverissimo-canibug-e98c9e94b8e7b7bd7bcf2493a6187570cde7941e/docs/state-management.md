# State Management

## Overview

The application uses [Tanstack Query](https://tanstack.com/query/latest) (formerly React Query) for state management. This choice was made because our application primarily deals with server state, and Tanstack Query provides excellent tools for handling server state with features like caching and invalidation.

## User Data Management

The user data is fetched and cached at specific points:

1. **Initial Load**: When the application first loads in the root layout
2. **After Login**: When a user successfully logs in
3. **On Model Changes**: When there are changes to the user or related models (boards, features)

We use an infinite stale time strategy, meaning the data is only refetched when explicitly invalidated. This is more efficient than time-based invalidation since user data rarely changes without the application knowing about it.

## Architecture

```mermaid
graph TD
    A[Root Layout] -->|Initial Fetch| B[QueryProvider]
    B -->|Hydrate| C[Query Cache]
    C -->|Provide| D[useUser Hook]
    D -->|Serve| E[Components]
    F[Server Actions] -->|Invalidate| C
    C -->|Refetch if Invalid| F
```

## Implementation Details

### Query Provider Setup

The application uses a singleton QueryClient to ensure consistent caching across the application:

```typescript
// src/lib/query-utils.ts
export function getQueryClient() {
  if (!queryClient) {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          staleTime: Infinity,  // Only refetch when invalidated
          gcTime: Infinity,     // Keep in cache until removed
        },
      },
    });
  }
  return queryClient;
}
```

### Server-Side Prefetching

Data is prefetched on the server in the root layout:

```typescript
// src/app/layout.tsx
const queryClient = getQueryClient();
const user = await getCurrentUser();
await queryClient.prefetchQuery({
  queryKey: userQueryKey,
  queryFn: () => user,
});
const dehydratedState = dehydrate(queryClient);
```

### User Data Hook

A custom hook provides access to user data with optimized caching:

```typescript
// src/hooks/use-user.ts
export function useUser() {
  const { data: user, refetch: refreshUser } = useQuery({
    queryKey: userQueryKey,
    queryFn: getCurrentUser,
    staleTime: Infinity,  // Only refetch when invalidated
    gcTime: Infinity,    // Keep in cache until removed
  });

  return {
    user,
    refreshUser,
    isSubscribed: user?.subscriptionStatus === "active",
  };
}
```

### Cache Invalidation

The cache is invalidated in specific scenarios:

```typescript
// src/lib/query-utils.ts
export function invalidateUserQueries() {
  const client = getQueryClient();
  return client.invalidateQueries({ queryKey: userQueryKey });
}
```

## Usage

To access user data in components:

```typescript
const { user, refreshUser, isSubscribed } = useUser();
```

To invalidate the cache when needed:

```typescript
await invalidateUserQueries();
```

## Benefits

1. **Efficient Caching**: Data is cached indefinitely until explicitly invalidated
2. **Consistent State**: Single source of truth for user data
3. **Optimized Fetching**: Only fetches when data is known to have changed
4. **Type Safety**: Full TypeScript support
5. **SSR Support**: Seamless server-side rendering with hydration
6. **DevTools**: Powerful development tools for debugging

## When to Invalidate

The user cache should be invalidated when:
1. User logs in or out
2. User's subscription status changes
3. User's boards or features are modified
4. User's profile is updated 