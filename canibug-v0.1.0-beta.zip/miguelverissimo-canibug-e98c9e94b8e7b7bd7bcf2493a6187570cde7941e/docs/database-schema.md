# Database Schema Documentation

## Entity Relationship Diagram

```plantuml
@startuml
!theme plain
skinparam linetype ortho

entity User {
  * id: ObjectId
  --
  * name: String
  * email: String
  hashedPassword: String
  emailVerified: DateTime
  image: String
  role: UserRole
  subscriptionStatus: SubscriptionStatus
  customerId: String
  * createdAt: DateTime
  * updatedAt: DateTime
}

entity Account {
  * id: ObjectId
  --
  * userId: ObjectId
  * type: String
  * provider: String
  * providerAccountId: String
  refresh_token: String
  access_token: String
  expires_at: Int
  token_type: String
  scope: String
  id_token: String
  session_state: String
  * createdAt: DateTime
  * updatedAt: DateTime
}

entity Session {
  * id: ObjectId
  --
  * sessionToken: String
  * userId: ObjectId
  * expires: DateTime
  * createdAt: DateTime
  * updatedAt: DateTime
}

entity VerificationToken {
  * id: ObjectId
  --
  * identifier: String
  * token: String
  * expires: DateTime
}

entity Board {
  * id: ObjectId
  --
  * userId: ObjectId
  * name: String
  * published: Boolean
  * createdAt: DateTime
  * updatedAt: DateTime
}

entity Feature {
  * id: ObjectId
  --
  * title: String
  description: String
  * userId: ObjectId
  * boardId: ObjectId
  * createdAt: DateTime
  * updatedAt: DateTime
}

enum UserRole {
  admin
  user
}

enum SubscriptionStatus {
  active
  inactive
}

User ||--o{ Account
User ||--o{ Session
User ||--o{ Board
User ||--o{ Feature
Board ||--o{ Feature

@enduml
```

## Schema Details

### User
The central entity representing application users.
- Primary key: `id` (ObjectId)
- Unique fields: `email`, `customerId`
- Relations:
  - One-to-Many with Account
  - One-to-Many with Session
  - One-to-Many with Board
  - One-to-Many with Feature

### Account
Stores OAuth account information for users.
- Primary key: `id` (ObjectId)
- Unique constraint: `[provider, providerAccountId]`
- Foreign key: `userId` references User
- Used for third-party authentication

### Session
Manages user sessions.
- Primary key: `id` (ObjectId)
- Unique field: `sessionToken`
- Foreign key: `userId` references User
- Handles user session management

### VerificationToken
Manages email verification tokens.
- Primary key: `id` (ObjectId)
- Unique constraint: `[identifier, token]`
- Used for email verification process

### Board
Represents a collection of features/bugs.
- Primary key: `id` (ObjectId)
- Foreign key: `userId` references User
- Contains features and their organization

### Feature
Represents individual features or bugs within a board.
- Primary key: `id` (ObjectId)
- Foreign keys:
  - `userId` references User (creator)
  - `boardId` references Board

## Enums

### UserRole
- `admin`: Administrator access
- `user`: Standard user access

### SubscriptionStatus
- `active`: User has an active subscription
- `inactive`: User has no active subscription

## Indexes and Performance

- Email index on User for quick lookups
- Compound index on Account for OAuth lookups
- Foreign key indexes for efficient joins
- Timestamp fields for data tracking

## Data Integrity

- Cascade deletes implemented for:
  - User -> Account
  - User -> Session
  - User -> Board
  - Board -> Feature
- Required fields marked with non-null constraints
- Unique constraints enforced on critical fields 