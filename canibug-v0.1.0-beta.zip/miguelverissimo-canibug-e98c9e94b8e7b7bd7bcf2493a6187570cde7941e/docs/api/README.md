# API Documentation

## Overview

The API is built using Next.js 15 Route Handlers, implementing RESTful endpoints for managing boards, features, and billing operations. All API routes are protected with Auth.js authentication.

## Base URL

```
/api
```

## Authentication

All API endpoints (except authentication endpoints) require a valid session cookie obtained through Auth.js authentication.

## API Endpoints

### Authentication

- [Authentication](./auth.md) - Auth.js endpoints for user authentication

### Boards

- [GET /api/boards](./boards/list.md) - List user's boards
- [POST /api/boards](./boards/create.md) - Create a new board
- [GET /api/boards/:id](./boards/get.md) - Get board details
- [PATCH /api/boards/:id](./boards/update.md) - Update board
- [DELETE /api/boards/:id](./boards/delete.md) - Delete board

### Features

- [GET /api/features](./features/list.md) - List features
- [POST /api/features](./features/create.md) - Create a new feature
- [GET /api/features/:id](./features/get.md) - Get feature details
- [PATCH /api/features/:id](./features/update.md) - Update feature
- [DELETE /api/features/:id](./features/delete.md) - Delete feature

### Billing

- [POST /api/billing/checkout](./billing/checkout.md) - Create checkout session
- [GET /api/billing/billing-portal](./billing/portal.md) - Access billing portal
- [POST /api/billing/webhook](./billing/webhook.md) - Handle Stripe webhooks

## Error Handling

All API endpoints follow a consistent error response format:

```typescript
{
  error: {
    message: string;
    code?: string;
    details?: Record<string, any>;
  }
}
```

### Common Error Codes

- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

## Rate Limiting

API endpoints are protected by rate limiting:

- 100 requests per minute per IP address
- 1000 requests per hour per user

## Data Validation

All request data is validated using Zod schemas:

- [Board Schema](../schemas/board-schema.md)
- [Feature Schema](../schemas/feature-schema.md)

## Versioning

The API is currently at v1 and is not versioned in the URL. Breaking changes will be communicated through the changelog.
