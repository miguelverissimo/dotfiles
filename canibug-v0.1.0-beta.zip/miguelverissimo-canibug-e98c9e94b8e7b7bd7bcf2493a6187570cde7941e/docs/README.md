# Can I Bug? Documentation

## Overview

Can I Bug? is a modern web application built with Next.js 15, React 19, and TypeScript. It helps users manage interruptions and focus on their work by providing a simple way to indicate their availability status.

## Architecture

The application follows a modern React architecture with:

- Next.js 15 App Router for routing and server components
- Tanstack Query for state management
- Prisma for database access
- Auth.js for authentication
- Stripe for payments
- Tailwind CSS and Daisy UI for styling

## Documentation Structure

- [State Management](./state-management.md) - Details about our Tanstack Query implementation
- [Database Schema](./database-schema.md) - Database structure and relationships
- [API Documentation](./api/README.md) - API endpoints and usage
- [Components](./components/README.md) - Reusable component documentation

## Diagrams

- [Component Architecture](./diagrams/component-architecture.puml) - Overall component structure
- [Database Schema](./diagrams/database-schema.puml) - Database relationships
- [State Management Flow](./diagrams/state-management.puml) - State management architecture

## Key Features

1. User Authentication
2. Subscription Management
3. Board Creation and Management
4. Feature Management
5. Real-time Availability Status

## Development

### Prerequisites

- Node.js 20+
- Bun package manager
- MongoDB database
- Stripe account for payments

### Getting Started

1. Clone the repository
2. Copy `.env.example` to `.env.local` and fill in the values
3. Run `bun install` to install dependencies
4. Run `bun dev` to start the development server

### Key Technologies

- Next.js 15 (App Router)
- React 19
- TypeScript
- Tanstack Query
- Prisma
- Auth.js
- Stripe
- Tailwind CSS
- Daisy UI 