# Components Documentation

## Overview

This documentation covers the shared components used throughout the application. All components are built using React 19, TypeScript, and styled with Tailwind CSS and Daisy UI.

## Component Categories

### Layout Components

- [Shell](./layout/shell.md) - Main application shell
- [Header](./layout/header.md) - Application header with navigation
- [Sidebar](./layout/sidebar.md) - Navigation sidebar

### Authentication Components

- [SignInButton](./auth/sign-in-button.md) - OAuth sign-in button
- [UserMenu](./auth/user-menu.md) - User profile dropdown menu

### Form Components

- [Input](./form/input.md) - Text input field
- [Button](./form/button.md) - Button component
- [Select](./form/select.md) - Select dropdown
- [Textarea](./form/textarea.md) - Multiline text input

### Data Display

- [Card](./data/card.md) - Card container
- [Table](./data/table.md) - Data table
- [Badge](./data/badge.md) - Status badge

### Feedback

- [Toast](./feedback/toast.md) - Toast notifications
- [Dialog](./feedback/dialog.md) - Modal dialogs
- [LoadingSpinner](./feedback/loading-spinner.md) - Loading indicator

## Component Architecture

```plantuml
@startuml
!theme plain
skinparam linetype ortho

package "Layout" {
  [Shell]
  [Header]
  [Sidebar]
}

package "Auth" {
  [SignInButton]
  [UserMenu]
}

package "Form" {
  [Input]
  [Button]
  [Select]
  [Textarea]
}

package "Data" {
  [Card]
  [Table]
  [Badge]
}

package "Feedback" {
  [Toast]
  [Dialog]
  [LoadingSpinner]
}

Shell --> Header
Shell --> Sidebar
Header --> UserMenu
UserMenu --> SignInButton

@enduml
```

## Component Guidelines

### Naming Conventions

- Use PascalCase for component names
- Prefix event handlers with "handle"
- Use descriptive prop names

### File Structure

```
components/
├── [category]/
│   ├── component-name/
│   │   ├── index.tsx
│   │   ├── component-name.tsx
│   │   └── component-name.test.tsx
│   └── README.md
└── README.md
```

### Props Interface

All components should have a well-defined props interface:

```typescript
interface ComponentProps {
  // Required props
  id: string;
  label: string;
  
  // Optional props with defaults
  variant?: "primary" | "secondary";
  disabled?: boolean;
  
  // Event handlers
  onChange?: (value: string) => void;
  
  // Children
  children?: React.ReactNode;
}
```

### Best Practices

1. Use TypeScript for type safety
2. Implement proper error boundaries
3. Follow accessibility guidelines
4. Write unit tests
5. Document props and usage
6. Use React Server Components where possible
7. Minimize client-side JavaScript

### Error Handling

Components should handle errors gracefully:
- Validate props with TypeScript
- Use error boundaries for runtime errors
- Provide meaningful error messages
- Fallback UI for error states

### Testing

All components should have:
- Unit tests with React Testing Library
- Accessibility tests
- Snapshot tests
- Integration tests where needed

### Performance

Optimize components by:
- Using React Server Components
- Implementing proper memoization
- Lazy loading when appropriate
- Minimizing re-renders
- Following React performance best practices 