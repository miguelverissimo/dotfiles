import { z } from "zod";

export const votingItemSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  boostBy: z.number().default(0).optional(),
});

export type VotingItemFormData = z.infer<typeof votingItemSchema>; 