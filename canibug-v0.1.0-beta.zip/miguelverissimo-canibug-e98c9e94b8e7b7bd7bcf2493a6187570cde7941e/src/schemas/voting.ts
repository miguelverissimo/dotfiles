import { z } from "zod";
import { VotingBoardVisibility } from "@/types/voting";

// Base schemas
export const votingBoardVisibilitySchema = z.enum([
  "public",
  "private",
  "restricted",
  "focusGroup",
  "innerCircle",
]) satisfies z.ZodType<VotingBoardVisibility>;

// Creation schemas
export const createVotingBoardSchema = z.object({
  name: z.string().min(1, "Name is required"),
  visibility: votingBoardVisibilitySchema.default("private"),
  openForVoting: z.boolean().default(false),
  openForNewItems: z.boolean().default(false),
  votersCanAddItems: z.boolean().default(false),
  published: z.boolean().default(false),
  votingStartsAt: z.preprocess((val) => {
    if (!val || val === "") return null;
    const date = new Date(val as string | number | Date);
    return isNaN(date.getTime()) ? null : date;
  }, z.date().nullable()),
  votingEndsAt: z.preprocess((val) => {
    if (!val || val === "") return null;
    const date = new Date(val as string | number | Date);
    return isNaN(date.getTime()) ? null : date;
  }, z.date().nullable()),
});

export const createVotingItemSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().max(2000).nullable(),
  boardId: z.string(),
});

export const createVotingItemVoteSchema = z.object({
  itemId: z.string(),
  voteValue: z.number().int().min(-1).max(1),
});

export const createVotingItemCommentSchema = z.object({
  itemId: z.string(),
  content: z.string().min(1).max(1000),
  votingBoardId: z.string().nullable(),
});

// Update schemas
export const updateVotingBoardSchema = createVotingBoardSchema.partial().extend({
  published: z.boolean().optional(),
  votingPausedAt: z.date().nullable(),
  votingPauseUntil: z.date().nullable(),
});

export const updateVotingItemSchema = createVotingItemSchema.partial().extend({
  boostBy: z.number().int().min(0).max(10).optional(),
});

export const updateVotingItemVoteSchema = createVotingItemVoteSchema.partial();

export const updateVotingItemCommentSchema = createVotingItemCommentSchema.partial();

// Query schemas
export const votingBoardQuerySchema = z.object({
  visibility: votingBoardVisibilitySchema.optional(),
  published: z.boolean().optional(),
  openForVoting: z.boolean().optional(),
  openForNewItems: z.boolean().optional(),
  userId: z.string().optional(),
  search: z.string().optional(),
  sort: z.enum(["recent", "popular", "active"]).optional(),
  page: z.number().int().min(1).optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

export const votingItemQuerySchema = z.object({
  boardId: z.string(),
  userId: z.string().optional(),
  search: z.string().optional(),
  sort: z.enum(["recent", "votes", "comments"]).optional(),
  page: z.number().int().min(1).optional(),
  limit: z.number().int().min(1).max(100).optional(),
});

// Response types
export type CreateVotingBoardInput = z.infer<typeof createVotingBoardSchema>;
export type UpdateVotingBoard = z.infer<typeof updateVotingBoardSchema>;
export type CreateVotingItem = z.infer<typeof createVotingItemSchema>;
export type UpdateVotingItem = z.infer<typeof updateVotingItemSchema>;
export type CreateVotingItemVote = z.infer<typeof createVotingItemVoteSchema>;
export type UpdateVotingItemVote = z.infer<typeof updateVotingItemVoteSchema>;
export type CreateVotingItemComment = z.infer<typeof createVotingItemCommentSchema>;
export type UpdateVotingItemComment = z.infer<typeof updateVotingItemCommentSchema>;
export type VotingBoardQuery = z.infer<typeof votingBoardQuerySchema>;
export type VotingItemQuery = z.infer<typeof votingItemQuerySchema>; 