import { z } from "zod";

export const settingSchema = z.object({
  type: z.enum(["option", "feature"]),
  name: z.string().min(1).trim(),
  value: z.string().min(1).trim(),
});

export type SettingSchema = z.infer<typeof settingSchema>;

