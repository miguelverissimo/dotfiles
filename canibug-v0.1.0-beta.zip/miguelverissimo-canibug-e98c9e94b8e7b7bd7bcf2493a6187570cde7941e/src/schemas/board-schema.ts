import { z } from "zod";

export const boardSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1).trim(),
  published: z.boolean().optional(),
});

export const boardIdSchema = boardSchema.pick({ id: true });

export type BoardSchema = z.infer<typeof boardSchema>;
export type BoardIdSchema = z.infer<typeof boardIdSchema>;
