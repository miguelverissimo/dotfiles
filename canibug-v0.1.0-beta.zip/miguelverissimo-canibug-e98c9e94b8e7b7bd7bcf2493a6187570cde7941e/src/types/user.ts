import { db } from "@/lib/prisma";
import { Types } from "@/types";
import { SerializedUserSettings, UserSettings } from "@/types/user-settings";

// Define the shape of our serialized user data
export interface SerializedUser {
  id: string;
  email: string | null;
  name: string | null;
  image: string | null;
  isSubscribed: boolean;
  role: string | null;
  settings: SerializedUserSettings | null;
  subscriptionStatus: string | null;
  isAdmin: boolean;
}

// Define a type that includes the settings relation
type UserWithSettings = Types.User & {
  settings: Types.UserSettings | null;
};

export class User {
  private user: UserWithSettings;
  private userSettings: UserSettings;

  constructor(user: UserWithSettings) {
    this.user = user;
    this.userSettings = new UserSettings(user, user.settings);
  }

  // Utility methods for user
  get id() { return this.user.id; }
  get email() { return this.user.email; }
  get name() { return this.user.name; }
  get image() { return this.user.image; }
  get isSubscribed() { return this.user.subscriptionStatus === "active"; }
  get settings() { return this.userSettings; }
  get role() { return this.user.role; }
  get subscriptionStatus() { return this.user.subscriptionStatus; }
  get isAdmin() { return this.user.role === "admin"; }

  // Convert to a plain object for serialization
  toJSON(): SerializedUser {
    return {
      id: this.id,
      email: this.email,
      name: this.name,
      image: this.image,
      isSubscribed: this.isSubscribed,
      role: this.role,
      settings: this.userSettings.toJSON(),
      subscriptionStatus: this.subscriptionStatus,
      isAdmin: this.isAdmin,
    };
  }

  // Create a helper to instantiate from database
  static async fromDatabase(userId: string): Promise<SerializedUser | null> {
    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        settings: true,
      }
    });

    return user ? new User(user).toJSON() : null;
  }
}