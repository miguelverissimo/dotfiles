import { User } from "@prisma/client";

export type VotingBoardVisibility = "public" | "private" | "restricted" | "focusGroup" | "innerCircle";

export interface VotingBoardStats {
  totalItems: number;
  totalVotes: number;
  totalComments: number;
  isActive: boolean;
  topVotedItem?: {
    title: string;
    votes: number;
  };
}

export interface VotingItemStats {
  totalVotes: number;
  totalComments: number;
  score: number;
}

export interface BaseVotingBoard {
  id: string;
  name: string;
  published: boolean;
  visibility: VotingBoardVisibility;
  openForVoting: boolean;
  openForNewItems: boolean;
  votersCanAddItems: boolean;
  votingStartsAt: Date | null;
  votingEndsAt: Date | null;
  votingPausedAt: Date | null;
  votingPauseUntil: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface VotingBoard extends BaseVotingBoard {
  userId: string;
  user: User;
  items: VotingItem[];
  comments: VotingItemComment[];
  _count?: {
    items: number;
    comments: number;
  };

  // Utility methods
  getStats(): VotingBoardStats;
  isVotingOpen(): boolean;
  canAddItems(): boolean;
  getTopItems(limit?: number): VotingItem[];
  getRecentItems(limit?: number): VotingItem[];
  getMostDiscussedItems(limit?: number): VotingItem[];
}

export interface BaseVotingItem {
  id: string;
  title: string;
  description: string | null;
  boostBy: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface VotingItem extends BaseVotingItem {
  userId: string;
  user: User;
  boardId: string;
  board: VotingBoard;
  votes: VotingItemVote[];
  comments: VotingItemComment[];
  _count?: {
    votes: number;
    comments: number;
  };

  // Utility methods
  getStats(): VotingItemStats;
  getTotalScore(): number;
  getUserVote(userId: string): VotingItemVote | null;
  getRecentComments(limit?: number): VotingItemComment[];
}

export interface BaseVotingItemVote {
  id: string;
  voteValue: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface VotingItemVote extends BaseVotingItemVote {
  itemId: string;
  item: VotingItem;
  userId: string;
  user: User;
}

export interface BaseVotingItemComment {
  id: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface VotingItemComment extends BaseVotingItemComment {
  itemId: string;
  item: VotingItem;
  userId: string;
  user: User;
  votingBoardId: string | null;
  board?: VotingBoard;
}

// Type guards
export const isVotingBoard = (obj: unknown): obj is VotingBoard => {
  return Boolean(obj && typeof obj === "object" && "visibility" in obj && "openForVoting" in obj);
};

export const isVotingItem = (obj: unknown): obj is VotingItem => {
  return Boolean(obj && typeof obj === "object" && "boardId" in obj && "title" in obj);
};

// Utility types for API responses
export type VotingBoardWithStats = VotingBoard & { stats: VotingBoardStats };
export type VotingItemWithStats = VotingItem & { stats: VotingItemStats };

// Types for different view contexts
export interface VotingBoardListItem extends BaseVotingBoard {
  stats: VotingBoardStats;
  _count: {
    items: number;
    comments: number;
  };
}

export interface VotingItemListItem extends BaseVotingItem {
  stats: VotingItemStats;
  userVote?: VotingItemVote;
  _count: {
    votes: number;
    comments: number;
  };
} 