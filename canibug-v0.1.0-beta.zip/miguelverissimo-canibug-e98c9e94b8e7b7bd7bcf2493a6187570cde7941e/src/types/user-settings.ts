import { db } from "@/lib/prisma";
import { Types } from "@/types";

export interface SerializedUserSettings {
  userId: string;
  data: Record<string, unknown>;
}

export class UserSettings {
  private user: Types.User;
  private settings: Types.UserSettings | null;

  constructor(user: Types.User, settings: Types.UserSettings | null) {
    this.user = user;
    this.settings = settings;
  }

  // Get a setting value with type safety
  get<T>(key: string, defaultValue: T): T {
    if (!this.settings) return defaultValue;
    const data = this.settings.data as Record<string, unknown>;
    return (data[key] as T) ?? defaultValue;
  }

  // Check if a boolean setting is enabled
  isEnabled(key: string): boolean {
    return this.get(key, false);
  }

  // Convert to a plain object for serialization
  toJSON(): SerializedUserSettings {
    return {
      userId: this.user.id,
      data: this.settings?.data as Record<string, unknown> ?? {},
    };
  }

  // Update settings
  async update(settings: Record<string, unknown>): Promise<SerializedUserSettings> {
    const data = {
      ...(this.settings?.data as Record<string, unknown>),
      ...settings
    };

    const updatedSettings = await db.userSettings.upsert({
      where: {
        userId: this.user.id
      },
      update: {
        data: data as Types.Prisma.InputJsonValue
      },
      create: {
        userId: this.user.id,
        data: data as Types.Prisma.InputJsonValue
      }
    });

    this.settings = updatedSettings;
    return this.toJSON();
  }
}