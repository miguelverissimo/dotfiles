import * as React from "react";
import { cn } from "@/lib/utils";

export interface DateTimePickerProps {
  value: Date | null;
  onChange: (date: Date | null) => void;
  className?: string;
}

export function DateTimePicker({
  value,
  onChange,
  className,
}: DateTimePickerProps) {
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = e.target.value ? new Date(e.target.value) : null;
    onChange(newDate);
  };

  return (
    <div className={cn("form-control", className)}>
      <input
        type="datetime-local"
        className="input input-bordered w-full"
        value={value ? value.toISOString().slice(0, 16) : ""}
        onChange={handleDateChange}
      />
    </div>
  );
} 