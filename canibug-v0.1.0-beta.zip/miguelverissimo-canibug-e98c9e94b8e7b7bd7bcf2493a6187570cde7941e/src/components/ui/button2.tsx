import { cn } from "@/lib/utils";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import * as React from "react";

const button2Variants = cva(
  "",
  {
    variants: {
      variant: {
        default: "btn",
        neutral: "btn btn-neutral",
        primary: "btn btn-primary",
        secondary: "btn btn-secondary",
        accent: "btn btn-accent",
        ghost: "btn btn-ghost",
        link: "btn btn-link",
        info: "btn btn-info",
        success: "btn btn-success",
        warning: "btn btn-warning",
        error: "btn btn-error",
      },
      active: {
        false: null,
        true: "btn-active",
      },
      outline: {
        false: null,
        true: "btn-outline",
      },
      responsive: {
        false: null,
        true: "btn-xs sm:btn-sm md:btn-md lg:btn-lg",
      },
      wide: {
        false: null,
        true: "btn-wide",
      },
      soft: {
        false: null,
        true: "btn-soft",
      },
      size: {
        sm: "btn-sm",
        lg: "btn-lg",
        xs: "btn-xs",
      },
    },
    defaultVariants: {
      variant: "default",
      active: false,
      outline: false,
      responsive: false,
      wide: false,
      soft: false,
    },
  }
);

export interface Button2Props
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
  VariantProps<typeof button2Variants> {
  children?: React.ReactNode;
  asChild?: boolean;
  active?: boolean;
  outline?: boolean;
  responsive?: boolean;
  wide?: boolean;
  soft?: boolean;
};

const Button2 = React.forwardRef<HTMLButtonElement, Button2Props>(
  ({ className, variant, size, active, outline, responsive, wide, asChild = false, children, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(button2Variants({ variant, size, active, outline, responsive, wide, className }))}
        ref={ref}
        {...props}
      >
        {children}
      </Comp>
    )
  }
);

Button2.displayName = "Button2";

export { Button2, button2Variants };
