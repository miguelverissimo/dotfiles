"use client";

import { useState, useEffect } from "react";
import Confetti from "react-confetti";

const ConfettiBlast = () => {
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    setDimensions({
      width: window.innerWidth,
      height: window.innerHeight,
    });
  }, []);

  return (
    <Confetti
      width={dimensions.width}
      height={dimensions.height}
    />
  );
};

export default ConfettiBlast;