import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { VotingItemComment } from "@/types/voting";
import { CreateVotingItemComment, UpdateVotingItemComment } from "@/schemas/voting";

const VOTING_COMMENTS_KEY = "voting-comments";
const VOTING_ITEMS_KEY = "voting-items";
const VOTING_BOARDS_KEY = "voting-boards";

// Fetch functions
const fetchItemComments = async (itemId: string): Promise<VotingItemComment[]> => {
  const { data } = await axios.get(`/api/voting-items/${itemId}/comments`);
  return data;
};

const fetchBoardComments = async (boardId: string): Promise<VotingItemComment[]> => {
  const { data } = await axios.get(`/api/voting-boards/${boardId}/comments`);
  return data;
};

// Mutation functions
const createVotingComment = async (comment: CreateVotingItemComment): Promise<VotingItemComment> => {
  const { data } = await axios.post("/api/voting-comments", comment);
  return data;
};

const updateVotingComment = async ({
  id,
  ...update
}: UpdateVotingItemComment & { id: string }): Promise<VotingItemComment> => {
  const { data } = await axios.patch(`/api/voting-comments/${id}`, update);
  return data;
};

const deleteVotingComment = async (id: string): Promise<void> => {
  await axios.delete(`/api/voting-comments/${id}`);
};

// Hooks
export const useItemComments = (itemId: string) => {
  return useQuery({
    queryKey: [VOTING_COMMENTS_KEY, "item", itemId],
    queryFn: () => fetchItemComments(itemId),
    enabled: !!itemId,
  });
};

export const useBoardComments = (boardId: string) => {
  return useQuery({
    queryKey: [VOTING_COMMENTS_KEY, "board", boardId],
    queryFn: () => fetchBoardComments(boardId),
    enabled: !!boardId,
  });
};

export const useCreateVotingComment = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createVotingComment,
    onSuccess: (data) => {
      // Invalidate item comments
      queryClient.invalidateQueries({
        queryKey: [VOTING_COMMENTS_KEY, "item", data.itemId]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, data.itemId]
      });

      // Invalidate board comments if applicable
      if (data.votingBoardId) {
        queryClient.invalidateQueries({
          queryKey: [VOTING_COMMENTS_KEY, "board", data.votingBoardId]
        });
        queryClient.invalidateQueries({
          queryKey: [VOTING_BOARDS_KEY, data.votingBoardId]
        });
      }
    },
  });
};

export const useUpdateVotingComment = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateVotingComment,
    onSuccess: (data) => {
      // Invalidate item comments
      queryClient.invalidateQueries({
        queryKey: [VOTING_COMMENTS_KEY, "item", data.itemId]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, data.itemId]
      });

      // Invalidate board comments if applicable
      if (data.votingBoardId) {
        queryClient.invalidateQueries({
          queryKey: [VOTING_COMMENTS_KEY, "board", data.votingBoardId]
        });
        queryClient.invalidateQueries({
          queryKey: [VOTING_BOARDS_KEY, data.votingBoardId]
        });
      }
    },
  });
};

export const useDeleteVotingComment = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteVotingComment,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_COMMENTS_KEY]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_BOARDS_KEY]
      });
    },
  });
}; 