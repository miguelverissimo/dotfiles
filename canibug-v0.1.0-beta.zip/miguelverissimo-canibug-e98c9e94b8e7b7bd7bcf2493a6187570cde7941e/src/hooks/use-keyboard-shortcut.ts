import { useEffect } from "react";

type KeyboardShortcut = "Escape" | "Meta+Enter";

export function useKeyboardShortcut(shortcut: KeyboardShortcut, callback: () => void) {
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (shortcut === "Escape" && event.key === "Escape") {
        callback();
      } else if (
        shortcut === "Meta+Enter" &&
        event.key === "Enter" &&
        (event.metaKey || event.ctrlKey)
      ) {
        event.preventDefault();
        callback();
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [shortcut, callback]);
} 