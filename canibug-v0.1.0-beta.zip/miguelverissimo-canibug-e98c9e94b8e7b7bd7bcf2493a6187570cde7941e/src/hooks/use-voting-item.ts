import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import {
  VotingItem,
  VotingItemListItem,
  VotingItemWithStats
} from "@/types/voting";
import {
  CreateVotingItem,
  UpdateVotingItem,
  VotingItemQuery
} from "@/schemas/voting";

const VOTING_ITEMS_KEY = "voting-items";

// Fetch functions
const fetchVotingItems = async (query: VotingItemQuery): Promise<VotingItemListItem[]> => {
  const { data } = await axios.get("/api/voting-items", { params: query });
  return data;
};

const fetchVotingItem = async (id: string): Promise<VotingItemWithStats> => {
  const { data } = await axios.get(`/api/voting-items/${id}`);
  return data;
};

// Mutation functions
const createVotingItem = async (item: CreateVotingItem): Promise<VotingItem> => {
  const { data } = await axios.post("/api/voting-items", item);
  return data;
};

const updateVotingItem = async ({
  id,
  ...update
}: UpdateVotingItem & { id: string }): Promise<VotingItem> => {
  const { data } = await axios.patch(`/api/voting-items/${id}`, update);
  return data;
};

const deleteVotingItem = async (id: string): Promise<void> => {
  await axios.delete(`/api/voting-items/${id}`);
};

// Hooks
export const useVotingItems = (query: VotingItemQuery) => {
  return useQuery({
    queryKey: [VOTING_ITEMS_KEY, query],
    queryFn: () => fetchVotingItems(query),
    enabled: !!query.boardId,
  });
};

export const useVotingItem = (id: string) => {
  return useQuery({
    queryKey: [VOTING_ITEMS_KEY, id],
    queryFn: () => fetchVotingItem(id),
    enabled: !!id,
  });
};

export const useCreateVotingItem = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createVotingItem,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, { boardId: data.boardId }]
      });
    },
  });
};

export const useUpdateVotingItem = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateVotingItem,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, data.id]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, { boardId: data.boardId }]
      });
    },
  });
};

export const useDeleteVotingItem = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteVotingItem,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY]
      });
    },
  });
}; 