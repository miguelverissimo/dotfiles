"use client";

import { getCurrentUser } from "@/lib/actions/user-actions";
import { SerializedUser } from "@/types/user";
import { useQuery } from "@tanstack/react-query";

export const userQueryKey = ["user"] as const;

export function useUser() {
  const { data: user, refetch: refreshUser, isLoading } = useQuery<SerializedUser | null>({
    queryKey: userQueryKey,
    queryFn: getCurrentUser,
    staleTime: 60 * 1000, // 1 minute
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  return {
    user,
    refreshUser,
    isLoading,
    isSubscribed: user?.isSubscribed,
  };
} 