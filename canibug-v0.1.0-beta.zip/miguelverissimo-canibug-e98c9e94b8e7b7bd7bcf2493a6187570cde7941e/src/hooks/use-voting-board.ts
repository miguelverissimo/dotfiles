import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import {
  VotingBoard,
  VotingBoardListItem,
  VotingBoardWithStats
} from "@/types/voting";
import {
  CreateVotingBoardInput,
  UpdateVotingBoard,
} from "@/schemas/voting";
import { z } from "zod";

const VOTING_BOARDS_KEY = "voting-boards";

// Query parameters schema
export const votingBoardsQuerySchema = z.object({
  visibility: z.enum(["public", "private", "restricted", "focusGroup", "innerCircle"] as const).optional(),
  open_for_voting: z.boolean().optional(),
  published: z.boolean().optional(),
  user_id: z.string().optional(),
});

export type VotingBoardsQuery = z.infer<typeof votingBoardsQuerySchema>;

// Fetch functions
const fetchVotingBoards = async (query?: VotingBoardsQuery): Promise<VotingBoardListItem[]> => {
  try {
    // Validate query parameters
    const validatedQuery = query ? votingBoardsQuerySchema.parse(query) : undefined;

    // Only include defined parameters
    const params = validatedQuery ? Object.entries(validatedQuery).reduce((acc, [key, value]) => {
      if (value !== undefined) {
        acc[key] = typeof value === 'boolean' ? String(value) : value;
      }
      return acc;
    }, {} as Record<string, string>) : undefined;

    const { data } = await axios.get("/api/voting-boards", {
      params
    });
    return data;
  } catch (error) {
    console.error("Failed to fetch voting boards:", error);
    throw error;
  }
};

const fetchVotingBoard = async (id: string): Promise<VotingBoardWithStats> => {
  const { data } = await axios.get(`/api/voting-boards/${id}`);
  return data;
};

// Mutation functions
const createVotingBoard = async (board: CreateVotingBoardInput): Promise<VotingBoard> => {
  const { data } = await axios.post("/api/voting-boards", board);
  return data;
};

const updateVotingBoard = async ({
  id,
  ...update
}: UpdateVotingBoard & { id: string }): Promise<VotingBoard> => {
  const { data } = await axios.patch(`/api/voting-boards/${id}`, update);
  return data;
};

const deleteVotingBoard = async (id: string): Promise<void> => {
  await axios.delete(`/api/voting-boards/${id}`);
};

// Hooks
export const useVotingBoards = (query?: VotingBoardsQuery) => {
  return useQuery({
    queryKey: [VOTING_BOARDS_KEY, query],
    queryFn: () => fetchVotingBoards(query),
    retry: 1,
    staleTime: 1000 * 60 // 1 minute
  });
};

export const useVotingBoard = (id: string) => {
  return useQuery({
    queryKey: [VOTING_BOARDS_KEY, id],
    queryFn: () => fetchVotingBoard(id),
    enabled: !!id,
  });
};

export const useCreateVotingBoard = () => {
  const queryClient = useQueryClient();

  const mutation = useMutation<
    VotingBoard,
    Error,
    CreateVotingBoardInput,
    unknown
  >({
    mutationFn: createVotingBoard,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [VOTING_BOARDS_KEY] });
    },
  });

  return {
    ...mutation,
    mutateAsync: mutation.mutateAsync,
    isLoading: mutation.isPending
  };
};

export const useUpdateVotingBoard = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateVotingBoard,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_BOARDS_KEY, data.id]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_BOARDS_KEY]
      });
    },
  });
};

export const useDeleteVotingBoard = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteVotingBoard,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [VOTING_BOARDS_KEY] });
    },
  });
}; 