import { useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { VotingItemVote } from "@/types/voting";
import { CreateVotingItemVote, UpdateVotingItemVote } from "@/schemas/voting";

const VOTING_VOTES_KEY = "voting-votes";
const VOTING_ITEMS_KEY = "voting-items";

// Mutation functions
const createVotingVote = async (vote: CreateVotingItemVote): Promise<VotingItemVote> => {
  const { data } = await axios.post("/api/voting-votes", vote);
  return data;
};

const updateVotingVote = async ({
  id,
  ...update
}: UpdateVotingItemVote & { id: string }): Promise<VotingItemVote> => {
  const { data } = await axios.patch(`/api/voting-votes/${id}`, update);
  return data;
};

const deleteVotingVote = async (id: string): Promise<void> => {
  await axios.delete(`/api/voting-votes/${id}`);
};

// Hooks
export const useCreateVotingVote = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createVotingVote,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, data.itemId]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_VOTES_KEY, data.itemId]
      });
    },
  });
};

export const useUpdateVotingVote = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateVotingVote,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY, data.itemId]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_VOTES_KEY, data.itemId]
      });
    },
  });
};

export const useDeleteVotingVote = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteVotingVote,
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [VOTING_VOTES_KEY]
      });
      queryClient.invalidateQueries({
        queryKey: [VOTING_ITEMS_KEY]
      });
    },
  });
}; 