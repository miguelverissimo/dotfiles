"use client";

import { boardSchema, BoardSchema } from "@/schemas/board-schema";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { useRouter } from "next/navigation";
import { SubmitHandler, useForm } from "react-hook-form";
import toast from "react-hot-toast";


const NewBoardForm = () => {
  const router = useRouter();

  const {
    register,
    handleSubmit,
    // setError, // NOTE: Keeping this as an example
    reset,
    formState: { errors, isSubmitting }
  } = useForm<BoardSchema>({
    resolver: zodResolver(boardSchema),
  });

  const onSubmit: SubmitHandler<BoardSchema> = async (data) => {
    await axios.post("/api/boards", data)
      .then(() => {
        reset();
        router.refresh();
        toast.success("Board created");
      })
      .catch((err) => {
        console.error(err);
        const errorMessage = err.response?.data?.error || "Something went wrong 😭";
        toast.error(errorMessage);
        // setError("root", { message: errorMessage }); // NOTE: Keeping this as an example
      });
  };


  return (
    <form onSubmit={handleSubmit(onSubmit)} className="bg-base-100 rounded-3xl p-8 space-y-8">
      <p className="text-lg font-bold">Create a new feedback board</p>
      <label className="form-control w-full">
        <div className="label">
          <span className="label-text">Board name</span>
        </div>
        <input
          {...register("name")}
          name="name"
          type="text"
          placeholder="e.g. Feedback board"
          className="input input-bordered w-full"
        />
        {errors.name && <p className="text-error">{errors.name.message}</p>}
      </label>

      <label className="form-control w-full cursor-pointer">
        <div className="label">
          <span className="label-text">Live? </span>
        </div>
        <input
          {...register("published")}
          type="checkbox"
          className="toggle toggle-primary"
          defaultChecked={false}
        />
      </label>

      <button className="btn btn-primary w-full" type="submit" disabled={isSubmitting}>
        {isSubmitting && (
          <span className="loading loading-spinner loading-xs"></span>
        )}
        Create board
      </button>

      {errors.root && <p className="text-error">{errors.root.message}</p>}
    </form>
  );
};

export default NewBoardForm;
