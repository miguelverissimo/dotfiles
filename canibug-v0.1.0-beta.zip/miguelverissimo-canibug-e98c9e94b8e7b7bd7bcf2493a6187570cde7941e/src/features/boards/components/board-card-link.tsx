"use client";

import { CopyIcon } from "lucide-react";
import toast from "react-hot-toast";

type BoardCardLinkProps = {
  boardId: string;
};

const BoardCardLink = ({ boardId }: BoardCardLinkProps) => {
  const boardLink = `${process.env.NEXT_PUBLIC_APP_URL}/b/${boardId}`;

  const copyLink = (link: string) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        // For modern browsers
        navigator.clipboard.writeText(link).then(() => {
          toast.success("Link copied to clipboard");
        });
      } else {
        // Fallback for older browsers
        const textarea = document.createElement("textarea");
        textarea.value = link;
        textarea.style.position = "fixed";
        textarea.style.left = "-999999px";
        textarea.style.top = "-999999px";
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        try {
          document.execCommand("copy");
          toast.success("Link copied to clipboard");
        } catch {
          toast.error("Failed to copy link");
        } finally {
          textarea.remove();
        }
      }
    } catch {
      toast.error("Failed to copy link");
    }
  };

  return (
    <div className="bg-base-100 text-sm rounded-2xl px-4 py-2.5 flex items-center gap-2 max-w-500">
      <p className="truncate">{boardLink}</p>
      <button
        className="btn btn-sm btn-neutral btn-square"
        onClick={() => copyLink(boardLink)}
      >
        <CopyIcon className="w-4 h-4" />
      </button>
    </div>
  );
};

export default BoardCardLink;