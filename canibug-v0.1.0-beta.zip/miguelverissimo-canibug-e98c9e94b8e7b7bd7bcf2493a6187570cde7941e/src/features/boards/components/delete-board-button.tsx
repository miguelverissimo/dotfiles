"use client";

import axios from "axios";
import { Trash2Icon } from "lucide-react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

type DeleteBoardButtonProps = {
  boardId: string;
};

const DeleteBoardButton = ({ boardId }: DeleteBoardButtonProps) => {
  const router = useRouter();

  const handleDeleteBoard = async () => {
    axios.delete("/api/boards", {
      data: {
        id: boardId,
      },
    })
      .then(() => {
        toast.success("Board deleted successfully");
        router.push("/dashboard");
      })
      .catch((error) => {
        console.error(error);
        const errorMessage = error.response?.data?.error || "Something went wrong 😭";
        toast.error(errorMessage);
      });
  };

  return (
    <>
      <button
        className="btn btn-ghost"
        onClick={() => (document.getElementById('delete-modal') as HTMLDialogElement).showModal()}
      >
        <Trash2Icon className="w-6 h-6" />
        <p className="sr-only">Delete Board</p>
      </button>

      <dialog id="delete-modal" className="modal modal-bottom sm:modal-middle">
        <div className="modal-box">
          <h3 className="font-bold text-lg">Delete Board</h3>
          <p className="py-4">Are you sure you want to delete this board? This action cannot be undone.</p>
          <div className="modal-action">
            <form method="dialog">
              <button className="btn btn-ghost">Cancel</button>
              <button
                className="btn btn-error ml-2"
                onClick={(e) => {
                  e.preventDefault();
                  (document.getElementById('delete-modal') as HTMLDialogElement).close();
                  handleDeleteBoard();
                }}
              >
                Delete
              </button>
            </form>
          </div>
        </div>
      </dialog>
    </>
  );
};

export default DeleteBoardButton;
