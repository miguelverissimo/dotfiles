"use client";

import axios from "axios";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";

const BillingPortalButton = () => {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const handleClick = async () => {
    if (isLoading) return;

    setIsLoading(true);
    axios
      .post("/api/billing/billing-portal", {
        returnUrl: window.location.href,
      })
      .then((res) => {
        console.log(res);
        router.push(res.data.url);
      })
      .catch((err) => {
        console.error(err);
        toast.error("Something went wrong 😭");
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <button className="btn btn-primary" onClick={handleClick}>
      {isLoading && (
        <span className="loading loading-spinner loading-xs"></span>
      )}
      Billing Portal
    </button>
  );
};

export default BillingPortalButton;