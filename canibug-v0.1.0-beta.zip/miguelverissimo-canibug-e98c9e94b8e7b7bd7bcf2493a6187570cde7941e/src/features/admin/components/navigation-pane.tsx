"use client";

import { useUser } from '@/hooks/use-user';
import { LayoutDashboard, Rows3, Users } from 'lucide-react';
import Link from 'next/link';
import { usePathname, notFound } from 'next/navigation';

const NavigationPane = ({ children }: { children: React.ReactNode }) => {
  const pathname = usePathname();
  const { user } = useUser();

  if (!user?.isAdmin) {
    return notFound();
  }

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/admin' },
    { icon: Users, label: 'Users', href: '/admin/users' },
    { icon: Rows3, label: 'Voting Boards', href: '/admin/boards' },
  ];

  return (
    <div className="drawer lg:drawer-open">
      <input id="admin-drawer" type="checkbox" className="drawer-toggle" />
      <div className="drawer-content">
        <div className="navbar bg-base-100 lg:hidden">
          <div className="flex-none">
            <label htmlFor="admin-drawer" className="btn btn-square btn-ghost drawer-button">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="inline-block w-5 h-5 stroke-current">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </label>
          </div>
          <div className="flex-1">
            <span className="text-xl font-bold">Admin Panel</span>
          </div>
        </div>
        <div className="p-4 lg:p-8">
          {children}
        </div>
      </div>
      <div className="drawer-side">
        <label htmlFor="admin-drawer" className="drawer-overlay"></label>
        <div className="menu p-4 w-80 min-h-full bg-base-200 text-base-content">
          <div className="font-bold text-xl mb-4 px-4 hidden lg:block">Admin Panel</div>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.href === '/admin'
              ? pathname === '/admin'
              : pathname.startsWith(item.href + '/') || pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`duration-200 flex items-center gap-3 p-3 rounded-lg hover:bg-base-300 ${isActive ? 'bg-primary text-primary-content hover:bg-primary disabled' : ''
                  }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default NavigationPane;