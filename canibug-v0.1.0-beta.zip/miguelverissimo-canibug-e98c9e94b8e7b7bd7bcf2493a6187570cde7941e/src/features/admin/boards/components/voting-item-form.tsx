"use client";

import { useEffect, useRef } from "react";
import { useVotingItemForm } from "../hooks/use-voting-item-form";
import { VotingItemFormData } from "@/schemas/voting-item.schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useKeyboardShortcut } from "@/hooks/use-keyboard-shortcut";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle } from "lucide-react";

interface VotingItemFormProps {
  mode: "create" | "edit";
  initialData?: VotingItemFormData;
  boardId: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function VotingItemForm({
  mode,
  initialData,
  boardId,
  onSuccess,
  onCancel,
}: VotingItemFormProps) {
  const { form, onSubmit, handleCancel, isLoading } = useVotingItemForm({
    mode,
    initialData,
    boardId,
    onSuccess,
    onCancel,
  });
  const dialogRef = useRef<HTMLDialogElement>(null);

  // Handle keyboard shortcuts
  useKeyboardShortcut("Escape", () => {
    if (form.formState.isDirty) {
      dialogRef.current?.showModal();
    } else {
      handleCancel();
    }
  });
  useKeyboardShortcut("Meta+Enter", () => {
    const submitButton = document.querySelector('button[type="submit"]');
    if (submitButton instanceof HTMLButtonElement) {
      submitButton.click();
    }
  });

  // Auto-focus title field on mount
  useEffect(() => {
    const titleInput = document.querySelector('input[name="title"]');
    if (titleInput instanceof HTMLInputElement) {
      titleInput.focus();
    }
  }, []);

  const handleCancelClick = () => {
    if (form.formState.isDirty) {
      dialogRef.current?.showModal();
    } else {
      handleCancel();
    }
  };

  return (
    <>
      <AnimatePresence mode="wait">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="w-full"
        >
          <Form {...form}>
            <form
              onSubmit={onSubmit}
              className="space-y-6 w-full max-w-2xl mx-auto bg-base-200 p-6 rounded-lg shadow-lg"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">
                  {mode === "create" ? "Add New Item" : "Edit Item"}
                </h3>
                {form.formState.errors.root && (
                  <div className="text-error flex items-center gap-2 text-sm">
                    <AlertCircle className="w-4 h-4" />
                    <span>{form.formState.errors.root.message}</span>
                  </div>
                )}
              </div>

              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter title"
                        {...field}
                        className="input input-bordered w-full focus:input-primary"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter description (optional)"
                        {...field}
                        value={field.value ?? ""}
                        className="textarea textarea-bordered w-full min-h-[100px] focus:textarea-primary"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="boostBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Boost Value</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="0"
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        className="input input-bordered w-full focus:input-primary"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-4 border-t border-base-300">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={handleCancelClick}
                  disabled={isLoading}
                  className="btn btn-ghost"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="btn btn-primary"
                >
                  {isLoading ? (
                    <span className="loading loading-spinner loading-sm" />
                  ) : null}
                  {mode === "create" ? "Create" : "Update"} Item
                </Button>
              </div>
            </form>
          </Form>
        </motion.div>
      </AnimatePresence>

      <dialog ref={dialogRef} className="modal modal-bottom sm:modal-middle">
        <div className="modal-box">
          <h3 className="font-bold text-lg">Discard Changes?</h3>
          <p className="py-4">You have unsaved changes. Are you sure you want to discard them?</p>
          <div className="modal-action">
            <form method="dialog">
              <Button
                type="button"
                className="btn btn-ghost mr-2"
                onClick={() => dialogRef.current?.close()}
              >
                Keep Editing
              </Button>
              <Button
                type="submit"
                className="btn btn-error"
                onClick={() => {
                  dialogRef.current?.close();
                  handleCancel();
                }}
              >
                Discard Changes
              </Button>
            </form>
          </div>
        </div>
        <form method="dialog" className="modal-backdrop">
          <button>close</button>
        </form>
      </dialog>
    </>
  );
} 