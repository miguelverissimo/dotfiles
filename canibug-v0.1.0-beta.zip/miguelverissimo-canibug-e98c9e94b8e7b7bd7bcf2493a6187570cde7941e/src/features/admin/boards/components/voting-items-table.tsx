import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { VotingItemListItem } from "@/types/voting";

interface VotingItemsTableProps {
  items?: VotingItemListItem[];
  isLoading?: boolean;
  onItemClick?: (itemId: string) => void;
}

export function VotingItemsTable({ items, isLoading, onItemClick }: VotingItemsTableProps) {
  if (isLoading) {
    return <ItemsTableSkeleton />;
  }

  const hasItems = items && items.length > 0;

  if (!hasItems) {
    return (
      <div className="text-center p-8 bg-base-200 rounded-lg">
        <p className="text-muted-foreground">No items yet</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Votes</th>
            <th>Comments</th>
            <th>Created</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {items?.sort((a, b) => b.stats.totalVotes - a.stats.totalVotes)
            .map((item) => (
              <tr
                key={item.id}
                className="hover:bg-base-200 cursor-pointer"
                onClick={() => onItemClick?.(item.id)}
              >
                <td>{item.title}</td>
                <td>{item.description}</td>
                <td>
                  <div className="badge badge-primary">
                    {item.stats.totalVotes}
                  </div>
                </td>
                <td>
                  <div className="badge badge-ghost">
                    {item._count.comments}
                  </div>
                </td>
                <td className="text-muted-foreground">
                  {format(new Date(item.createdAt), "MMM d, yyyy")}
                </td>
                <td></td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export function ItemsTableSkeleton() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-24" />
        </div>
      ))}
    </div>
  );
} 