import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "react-hot-toast";
import { useRouter } from "next/navigation";
import { VotingItemFormData, votingItemSchema } from "@/schemas/voting-item.schema";
import { useCreateVotingItem } from "@/hooks/use-voting-item";

interface UseVotingItemFormProps {
  mode: "create" | "edit";
  initialData?: VotingItemFormData;
  boardId: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function useVotingItemForm({
  mode,
  initialData,
  boardId,
  onSuccess,
  onCancel,
}: UseVotingItemFormProps) {
  const router = useRouter();
  const createItem = useCreateVotingItem();

  const form = useForm<VotingItemFormData>({
    resolver: zodResolver(votingItemSchema),
    defaultValues: initialData || {
      title: "",
      description: "",
      boostBy: 0,
    },
  });

  const onSubmit = async (data: VotingItemFormData) => {
    try {
      if (mode === "create") {
        await createItem.mutateAsync({
          ...data,
          boardId,
          description: data.description || null,
        });
        toast.success("Voting item created successfully");
      } else {
        // TODO: Implement edit mode
        toast.success("Voting item updated successfully");
      }
      router.refresh();
      onSuccess?.();
    } catch (error) {
      toast.error("Something went wrong");
      console.error(error);
    }
  };

  const handleCancel = () => {
    form.reset();
    onCancel?.();
  };

  return {
    form,
    onSubmit: form.handleSubmit(onSubmit),
    handleCancel,
    isLoading: form.formState.isSubmitting || createItem.isPending,
  };
} 