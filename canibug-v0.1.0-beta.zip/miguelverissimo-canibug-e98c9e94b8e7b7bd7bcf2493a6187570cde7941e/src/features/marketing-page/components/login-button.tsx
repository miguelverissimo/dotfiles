"use client";

import { Button2, button2Variants } from "@/components/ui/button2";
import { cn } from "@/lib/utils";
import { VariantProps } from "class-variance-authority";
import { Session } from "next-auth";
import { signIn, signOut } from "next-auth/react";

interface LoginButtonProps {
  session: Session | null;
  variant?: VariantProps<typeof button2Variants>['variant'];
  fullWidth?: boolean;
  className?: string;
};

export function LoginButton({ session, variant, fullWidth, className }: LoginButtonProps) {
  const buttonText = session ? `Welcome back${session.user?.name ? `, ${session.user.name.split(" ")[0]}` : ""}` : "End Distractions";

  return (
    <Button2
      variant={variant || "accent"}
      className={fullWidth ? cn("w-full", className) : className}
      onClick={() => session ? signOut() : signIn(undefined, { callbackUrl: "/dashboard" })}
    >
      {buttonText}
    </Button2>
  );
};
