"use client";

import { Button2, button2Variants } from "@/components/ui/button2";
import { cn } from "@/lib/utils";
import { VariantProps } from "class-variance-authority";
import { signOut } from "next-auth/react";

interface LogoutButtonProps {
  variant?: VariantProps<typeof button2Variants>['variant'];
  fullWidth?: boolean;
  className?: string;
};

export function LogoutButton({ variant, fullWidth, className }: LogoutButtonProps) {
  const buttonText = "Logout";

  return (
    <Button2
      variant={variant || "ghost"}
      className={fullWidth ? cn("w-full", className) : className}
      onClick={() => signOut()}
    >
      {buttonText}
    </Button2>
  );
};
