import React from "react";

type FeaturesItemProps = {
  title: string;
  children?: React.ReactNode;
};

const FeaturesItem = ({ title, children }: FeaturesItemProps) => {
  return (
    <div tabIndex={0} className="collapse collapse-plus border-base-300 bg-base-200 border">
      <div className="collapse-title text-xl font-medium">{title}</div>
      <div className="collapse-content">
        {children}
      </div>
    </div>
  );
};

export default FeaturesItem;