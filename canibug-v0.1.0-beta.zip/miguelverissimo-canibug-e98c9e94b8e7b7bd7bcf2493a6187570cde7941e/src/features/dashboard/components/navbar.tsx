"use client";

import { useUser } from "@/hooks/use-user";
import { signOut } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef } from "react";
import BillingPortalLink from "./billing/billing-portal-link";

const Navbar = () => {
  const { user, isLoading } = useUser();
  const router = useRouter();
  const detailsRef = useRef<HTMLDetailsElement>(null);
  const imageUrl = user?.image || "/default-avatar.png";

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        detailsRef.current?.removeAttribute('open');
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, []);

  const handleSignOut = () => {
    detailsRef.current?.removeAttribute('open');
    signOut({ callbackUrl: "/" });
  };

  const handleNavigation = (path: string) => {
    detailsRef.current?.removeAttribute('open');
    router.push(path);
  };

  return (
    <div className="navbar bg-base-100 shadow-sm">
      <div className="flex-1">
        <Link
          className="btn btn-ghost text-xl"
          href="/dashboard"
        >
          Can I Bug?
        </Link>
      </div>
      <div className="flex gap-2">
        <div className="">
          <Link
            className="btn btn-ghost"
            href="/settings"
          >
            Testing
          </Link>
        </div>

        <div className="dropdown dropdown-end">
          <details ref={detailsRef} className="dropdown">
            <summary className="btn btn-ghost btn-circle avatar">
              <div className="w-10 rounded-full">
                {!isLoading && (
                  <Image
                    alt={`${user?.name || "User"}'s avatar`}
                    src={imageUrl}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                )}
              </div>
            </summary>
            {!isLoading && (
              <ul className="menu menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow">
                <li><button onClick={() => handleNavigation('/profile')} className="justify-between">Profile</button></li>
                <li><button onClick={() => handleNavigation('/settings')}>Settings</button></li>
                {user?.role === "admin" && <li><button onClick={() => handleNavigation('/admin')}>Admin</button></li>}
                {user?.isSubscribed && <li><BillingPortalLink /></li>}
                <li><button onClick={handleSignOut}>Logout</button></li>
              </ul>
            )}
          </details>
        </div>
      </div>
    </div>
  );
};

export default Navbar;