import { userQueryKey } from "@/hooks/use-user";
import { QueryClient } from "@tanstack/react-query";

// Singleton QueryClient for server-side operations
let queryClient: QueryClient | null = null;

export function getQueryClient() {
  if (!queryClient) {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          staleTime: Infinity,
          gcTime: Infinity,
        },
      },
    });
  }
  return queryClient;
}

export function invalidateUserQueries() {
  const client = getQueryClient();
  return client.invalidateQueries({ queryKey: userQueryKey });
} 