import { db } from "@/lib/prisma";
import { Types } from "@/types";

export class CustomerIdError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CustomerIdError";
  }
}

/**
 * Safely assigns a Stripe customerId to a user with proper error handling and uniqueness checks.
 * Uses a transaction to ensure atomicity of the operation.
 */
export async function safelyAssignCustomerId(params: {
  userId: string;
  customerId: string;
  subscriptionStatus?: Types.SubscriptionStatus;
}) {
  const { userId, customerId, subscriptionStatus } = params;

  try {
    // Use a transaction to ensure atomicity
    return await db.$transaction(async (tx) => {
      // Check if customerId is already in use
      const existingUser = await tx.user.findFirst({
        where: { customerId },
        select: { id: true, email: true },
      });

      if (existingUser) {
        throw new CustomerIdError(
          `CustomerId ${customerId} is already assigned to user ${existingUser.id}`
        );
      }

      // Check if target user exists
      const targetUser = await tx.user.findUnique({
        where: { id: userId },
        select: { id: true, email: true, customerId: true },
      });

      if (!targetUser) {
        throw new CustomerIdError(`User ${userId} not found`);
      }

      if (targetUser.customerId) {
        throw new CustomerIdError(
          `User ${userId} already has customerId ${targetUser.customerId}`
        );
      }

      // Update user with new customerId
      return await tx.user.update({
        where: { id: userId },
        data: {
          customerId,
          ...(subscriptionStatus && { subscriptionStatus }),
        },
      });
    });
  } catch (error) {
    if (error instanceof CustomerIdError) {
      throw error;
    }

    // Log the error for debugging but throw a generic error for security
    console.error("Error in safelyAssignCustomerId:", error);
    throw new Error("Failed to assign customer ID");
  }
} 