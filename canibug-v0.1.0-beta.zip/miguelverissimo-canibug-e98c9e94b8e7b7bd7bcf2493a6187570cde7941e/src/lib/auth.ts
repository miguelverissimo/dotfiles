import { PrismaAdapter } from "@auth/prisma-adapter";
import NextAuth from "next-auth";
import GitHub from "next-auth/providers/github";
import Resend from "next-auth/providers/resend";
import Google from "next-auth/providers/google";
import { db } from "@/lib/prisma";
import type { User } from "next-auth";

const config = {
  adapter: PrismaAdapter(db),
  providers: [
    GitHub({
      clientId: process.env.AUTH_GITHUB_ID,
      clientSecret: process.env.AUTH_GITHUB_SECRET,
    }),
    Resend({
      from: "noreply@resend.canibug.com",
      apiKey: process.env.AUTH_RESEND_KEY,
      name: "Email",
    }),
    Google({
      clientId: process.env.AUTH_GOOGLE_ID,
      clientSecret: process.env.AUTH_GOOGLE_SECRET,
    }),
  ],
  events: {
    createUser: async ({ user }: { user: User }) => {
      // Create default user settings when a new user signs up
      if (!user.id) return;

      await db.userSettings.create({
        data: {
          userId: user.id,
          data: {
            displayName: user.name,
            emailNotifications: true,
            marketingEmails: true,
            pushNotifications: true,
            theme: "system",
            emailDigest: "daily",
            language: "english"
          }
        }
      });
    }
  },
  // debug: process.env.NODE_ENV === "development",
};

export const { handlers, signIn, signOut, auth } = NextAuth(config);
