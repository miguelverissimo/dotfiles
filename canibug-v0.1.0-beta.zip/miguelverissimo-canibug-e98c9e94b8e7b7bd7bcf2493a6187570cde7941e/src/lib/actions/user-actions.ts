import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { SerializedUser, User } from "@/types/user";
import { Prisma } from "@prisma/client";

export async function getCurrentUser(): Promise<SerializedUser | null> {
  const session = await auth();
  if (!session?.user?.id) return null;

  return User.fromDatabase(session.user.id);
}

export interface GetUsersOptions {
  page?: number;
  limit?: number;
  search?: string;
}

export interface GetUsersResponse {
  users: SerializedUser[];
  totalUsers: number;
  totalPages: number;
}

export async function getUsers({
  page = 1,
  limit = 10,
  search = ""
}: GetUsersOptions = {}): Promise<GetUsersResponse> {
  try {
    console.log('Fetching users with params:', { page, limit, search });

    const where: Prisma.UserWhereInput = search ? {
      OR: [
        { email: { contains: search, mode: 'insensitive' as Prisma.QueryMode } },
        { name: { contains: search, mode: 'insensitive' as Prisma.QueryMode } }
      ]
    } : {};

    const [users, totalUsers] = await Promise.all([
      db.user.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        include: {
          settings: true
        },
        orderBy: {
          createdAt: 'desc'
        }
      }),
      db.user.count({ where })
    ]);

    console.log('Found users:', users.length, 'Total:', totalUsers);

    const serializedUsers = users.map(user => {
      try {
        return new User({ ...user, settings: user.settings }).toJSON();
      } catch (error) {
        console.error('Error serializing user:', user.id, error);
        throw new Error(`Failed to serialize user ${user.id}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    });

    const totalPages = Math.ceil(totalUsers / limit);

    return {
      users: serializedUsers,
      totalUsers,
      totalPages
    };
  } catch (error) {
    console.error('Error in getUsers:', error);
    throw new Error(`Failed to fetch users: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}