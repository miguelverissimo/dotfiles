import "@/app/globals.css";
import { getCurrentUser } from "@/lib/actions/user-actions";
import { QueryProvider } from "@/providers/query-provider";
import type { Metadata } from "next";
import { Geist, Geist_Mono, Inter } from "next/font/google";
import { Toaster } from "react-hot-toast";
import { dehydrate } from "@tanstack/react-query";
import { getQueryClient } from "@/lib/query-utils";
import { auth } from "@/lib/auth";
import { SessionProvider } from "next-auth/react";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const inter = Inter({
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Can I Bug?",
  description: "Block interruptions, focus on what you want.",
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
    other: [
      { rel: "android-icon", sizes: "192x192", url: "/android-chrome-192x192.png" },
      { rel: "android-icon", sizes: "512x512", url: "/android-chrome-512x512.png" },
    ],
  },
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const queryClient = getQueryClient();
  const user = await getCurrentUser();
  const session = await auth();

  await queryClient.prefetchQuery({
    queryKey: ['user'] as const,
    queryFn: () => Promise.resolve(user),
    staleTime: Infinity,
    gcTime: Infinity,
  });
  const dehydratedState = dehydrate(queryClient);

  return (
    <html lang="en" data-theme="batechapas" className="scroll-smooth">
      <body className={`${inter.className} ${geistSans.variable} ${geistMono.variable} antialiased`}>
        <SessionProvider session={session}>
          <QueryProvider initialData={dehydratedState}>
            <div>
              <Toaster />
            </div>
            {children}
          </QueryProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
