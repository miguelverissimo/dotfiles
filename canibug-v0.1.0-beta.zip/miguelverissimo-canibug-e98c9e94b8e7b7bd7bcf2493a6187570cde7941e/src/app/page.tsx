import FeaturesItem from "@/features/marketing-page/components/features-item";
import { LoginButton } from "@/features/marketing-page/components/login-button";
import Image from "next/image";
import { auth } from "@/lib/auth";

export default async function Home() {
  const session = await auth();

  return (
    <main>
      {/* NAVIGATION */}
      <section className="bg-base-200">
        <div className="mx-auto max-w-4xl flex justify-between items-center">
          <div className="p-2 text-2xl font-bold">Can I Bug?</div>
          <div className="space-x-4 max-md:hidden">
            <a className="link link-hover" href="#features">Features</a>
            <a className="link link-hover" href="#pricing">Pricing</a>
          </div>
          <div className="p-2">
            <LoginButton session={session} />
          </div>
        </div>
      </section>

      {/* HERO */}
      <section className="text-center lg:text-left px-8 py-32 max-w-5xl mx-auto flex flex-col lg:flex-row items-center lg:items-start gap-14">
        <Image className="w-96 rounded-xl" src="/productDemo.jpeg" alt="Can I bug? Product Demo" width={800} height={500} />
        <div className="">
          <h1 className="text-4xl lg:text-5xl font-extrabold mb-6">
            Block interruptions, focus on what you want.
          </h1>
          <div className="text-lg opacity-80 mb-10">
            Elegantly show people of your immediate availability, and keep your headspace free from interruptions.
          </div>
          <LoginButton session={session} />
        </div>
      </section>

      {/* FEATURES */}
      <section className="bg-base-200" id="features">
        <div className="px-8 py-32 max-w-4xl mx-auto">
          <p className="pb-6 text-sm uppercase font-bold text-center text-primary">Features</p>
          <h2 className="text-3xl lg:text-4xl font-extrabold mb-12 text-center">
            Simple features to protect your time
          </h2>
          <div>
            {
              [
                {
                  title: "Show your availability in your own personal page",
                  description: "Share a link to anyone that displays your current availability to be interrupted.",
                },
                {
                  title: "Receive messages from your connections assyncronously",
                  description: "When you're unavailable, your contacts can still message you, but you'll only see them when you become available.",
                },
              ].map((feature) => (
                <FeaturesItem key={feature.title} title={feature.title}>
                  <p>{feature.description}</p>
                </FeaturesItem>
              ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="bg-base-200" id="pricing">
        <div className="px-8 py-32 max-w-4xl mx-auto">
          <p className="pb-6 text-sm uppercase font-bold text-center text-primary">Pricing</p>
          <h2 className="text-3xl lg:text-4xl font-extrabold mb-12 text-center">
            The only honest price pegging metric
          </h2>

          <div className="p-8 bg-base-100 max-w-96 rounded-3xl mx-auto space-y-6">
            <div className="flex gap-2 items-baseline">
              <div className="text-4xl font-black">$19</div>
              <div className="uppercase text-sm font-medium opacity-60">/month</div>
            </div>

            <ul className="mt-8 space-y-2">
              {["Connections", "Messages", "Interrupts"].map((benefit) => (
                <li className="flex gap-2 items-center" key={benefit}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 16 16"
                    fill="currentColor"
                    className="text-green-500 size-4"
                  >
                    <path fillRule="evenodd" d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
                  </svg>
                  {benefit}
                </li>
              ))}
            </ul>

            <LoginButton session={session} fullWidth />
          </div>
        </div>
      </section>
    </main>
  );
}
