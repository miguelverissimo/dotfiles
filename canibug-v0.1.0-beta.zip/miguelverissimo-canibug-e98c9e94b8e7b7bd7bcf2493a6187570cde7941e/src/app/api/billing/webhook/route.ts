import { CustomerIdError, safelyAssignCustomerId } from "@/lib/billing-utils";
import { db } from "@/lib/prisma";
import { Types } from "@/types";
import { NextResponse } from "next/server";
import Stripe from "stripe";

export async function POST(req: Request): Promise<NextResponse> {
  try {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    const stripeApiKey = process.env.STRIPE_API_KEY;

    if (!webhookSecret || !stripeApiKey) {
      throw new Error("Missing required environment variables");
    }

    const stripe = new Stripe(stripeApiKey);
    const body = await req.text();

    // Get the signature from request headers directly
    const signature = req.headers.get("stripe-signature") ?? "";

    if (!signature) {
      return NextResponse.json(
        { error: "Missing stripe-signature header" },
        { status: 400 }
      );
    }

    const event = stripe.webhooks.constructEvent(
      body,
      signature,
      webhookSecret
    );

    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutSessionCompleted(event.data.object as Stripe.Checkout.Session);
        break;
      case "customer.subscription.deleted":
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
        break;
      default:
        console.warn(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true }, { status: 200 });
  } catch (error) {
    console.error("[Stripe Webhook Error]:", error);

    if (error instanceof CustomerIdError) {
      return NextResponse.json(
        { error: error.message },
        { status: 409 } // Conflict
      );
    }

    // Don't expose internal errors to the client
    return NextResponse.json(
      { error: "Webhook Error" },
      { status: 500 }
    );
  }
}

async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session): Promise<void> {
  if (!session.client_reference_id) {
    throw new Error("Missing client_reference_id in session");
  }

  if (!session.customer) {
    throw new Error("Missing customer in session");
  }

  await safelyAssignCustomerId({
    userId: session.client_reference_id,
    customerId: session.customer as string,
    subscriptionStatus: Types.SubscriptionStatus.active,
  });
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription): Promise<void> {
  // First find the user by customerId
  const user = await db.user.findFirst({
    where: { customerId: subscription.customer as string },
    select: { id: true },
  });

  if (!user) {
    throw new Error(`No user found with customerId: ${subscription.customer}`);
  }

  // Then update using the user's id
  await db.user.update({
    where: { id: user.id },
    data: {
      subscriptionStatus: Types.SubscriptionStatus.inactive,
    },
  });
}
