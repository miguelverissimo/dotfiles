import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { Types } from "@/types";
import { NextResponse } from "next/server";
import Stripe from "stripe";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    if (!body.returnUrl) {
      return new NextResponse("Missing returnUrl", { status: 400 });
    }

    const session = await auth();

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { id: session.user?.id },
    });

    if (!user) {
      return new NextResponse("User not found", { status: 404 });
    }

    if (user.subscriptionStatus !== Types.SubscriptionStatus.active) {
      return new NextResponse("Please subscribe first 🙏", { status: 403 });
    }

    const stripe = new Stripe(process.env.STRIPE_API_KEY!);

    const billingPortalSession = await stripe.billingPortal.sessions.create({
      customer: user.customerId!,
      return_url: body.returnUrl,
    });

    return NextResponse.json({ url: billingPortalSession.url });
  } catch (error) {
    console.error(error);
    return new NextResponse("Internal server error", { status: 500 });
  }
}
