import { db } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";
import { VotingItem, VotingItemVote } from "@prisma/client";
import { z } from "zod";

const createItemSchema = z.object({
  title: z.string(),
  description: z.string().nullable(),
  boardId: z.string(),
});

type VotingItemWithRelations = VotingItem & {
  _count: {
    votes: number;
    VotingItemComment: number;
  };
  votes: VotingItemVote[];
};

type VotingItemWithStats = VotingItemWithRelations & {
  stats: {
    totalVotes: number;
    totalComments: number;
    score: number;
  };
};

export async function GET(request: Request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const boardId = searchParams.get("boardId");

    if (!boardId) {
      return new NextResponse("Board ID is required", { status: 400 });
    }

    const items = await db.votingItem.findMany({
      where: {
        boardId,
      },
      include: {
        _count: {
          select: {
            votes: true,
            VotingItemComment: true,
          },
        },
        votes: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    }) as VotingItemWithRelations[];

    // Transform items to include stats
    const transformedItems: VotingItemWithStats[] = items.map(item => ({
      ...item,
      stats: {
        totalVotes: item._count.votes,
        totalComments: item._count.VotingItemComment,
        score: item._count.votes + (item.boostBy || 0),
      }
    }));

    return NextResponse.json(transformedItems);
  } catch (error) {
    console.error("[VOTING_ITEMS_GET]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await request.json();
    const validatedData = createItemSchema.parse(body);

    if (!session.user.id) {
      return new NextResponse("User ID is required", { status: 400 });
    }

    const item = await db.votingItem.create({
      data: {
        title: validatedData.title,
        description: validatedData.description,
        boardId: validatedData.boardId,
        userId: session.user.id,
      },
      include: {
        _count: {
          select: {
            votes: true,
            VotingItemComment: true,
          },
        },
        votes: true,
      },
    }) as VotingItemWithRelations;

    const transformedItem: VotingItemWithStats = {
      ...item,
      stats: {
        totalVotes: item._count.votes,
        totalComments: item._count.VotingItemComment,
        score: item._count.votes + (item.boostBy || 0),
      }
    };

    return NextResponse.json(transformedItem);
  } catch (error) {
    console.error("[VOTING_ITEMS_POST]", error);
    if (error instanceof z.ZodError) {
      return new NextResponse(JSON.stringify(error.errors), { status: 400 });
    }
    return new NextResponse("Internal error", { status: 500 });
  }
} 