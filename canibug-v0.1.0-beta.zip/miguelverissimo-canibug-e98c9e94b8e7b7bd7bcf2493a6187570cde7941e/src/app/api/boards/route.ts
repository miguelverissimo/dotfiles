import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { boardIdSchema, boardSchema } from "@/schemas/board-schema";
import { Types } from "@/types";
import { NextResponse } from "next/server";
import { z } from "zod";

async function getUserAndSubscriptionStatus() {
  const session = await auth();
  if (!session?.user) {
    return {
      user: null,
      isSubscribed: false,
      errorMessage: "Unauthorized",
      statusCode: 401,
    }
  }

  const user: Types.User | null = await db.user.findUnique({
    where: {
      id: session.user.id as string,
    },
  });

  let errorMessage = null;
  let statusCode = 200;
  const isSubscribed = user?.subscriptionStatus === Types.SubscriptionStatus.active;

  if (!user) {
    errorMessage = "User not found";
    statusCode = 404;
  } else if (!isSubscribed) {
    errorMessage = "Please subscribe first 🙏";
    statusCode = 403;
  }

  return {
    user,
    isSubscribed: user?.subscriptionStatus === Types.SubscriptionStatus.active,
    errorMessage,
    statusCode,
  };
}

export async function POST(req: Request) {
  try {
    const { user, isSubscribed, errorMessage, statusCode } = await getUserAndSubscriptionStatus();
    if (!isSubscribed) {
      return NextResponse.json(
        { error: errorMessage },
        { status: statusCode }
      );
    }

    const { name, published } = boardSchema.parse(await req.json());
    const board: Types.VotingBoard | null = await db.votingBoard.create({
      data: {
        userId: user?.id as string,
        name,
        published,
      },
    });

    return NextResponse.json(board);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.message },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: `Internal Server Error: ${error}` },
      { status: 500 }
    );
  }
};

export async function DELETE(req: Request) {
  const { user, isSubscribed, errorMessage, statusCode } = await getUserAndSubscriptionStatus();
  if (!isSubscribed) {
    return NextResponse.json(
      { error: errorMessage },
      { status: statusCode }
    );
  }

  const { id } = boardIdSchema.parse(await req.json());

  await db.votingBoard.delete({
    where: {
      id,
      userId: user?.id as string,
    },
  }).catch((error) => {
    return NextResponse.json({ error: `Error deleting board: ${error}` }, { status: 500 });
  });

  return new NextResponse(null, { status: 204 });
}

export async function PUT(req: Request) {
  const { user, isSubscribed, errorMessage, statusCode } = await getUserAndSubscriptionStatus();
  if (!isSubscribed) {
    return NextResponse.json(
      { error: errorMessage },
      { status: statusCode }
    );
  }

  try {
    const { id, name, published } = boardSchema.parse(await req.json());

    const board = await db.votingBoard.update({
      where: {
        id,
        userId: user?.id as string,
      },
      data: {
        name,
        published,
      },
    });

    return NextResponse.json(board);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: error.message },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: `Internal Server Error: ${error}` },
      { status: 500 }
    );
  }
}
