import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { createVotingBoardSchema } from "@/schemas/voting";
import { VotingBoard, VotingBoardVisibility, VotingItem, Prisma } from "@prisma/client";
import { NextResponse } from "next/server";

type BoardWithRelations = VotingBoard & {
  items: (VotingItem & {
    _count: {
      votes: number;
    };
  })[];
  _count: {
    items: number;
    comments: number;
  };
};

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const json = await req.json();
    const body = createVotingBoardSchema.parse(json);

    const board = await db.votingBoard.create({
      data: {
        name: body.name,
        visibility: body.visibility as VotingBoardVisibility,
        openForVoting: body.openForVoting,
        openForNewItems: body.openForNewItems,
        votersCanAddItems: body.votersCanAddItems,
        published: body.published,
        votingStartsAt: body.votingStartsAt,
        votingEndsAt: body.votingEndsAt,
        user: {
          connect: {
            id: session.user.id
          }
        }
      },
      include: {
        _count: {
          select: {
            items: true,
            comments: true,
          }
        }
      }
    });

    return NextResponse.json(board);
  } catch (error) {
    console.error("[VOTING_BOARDS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  console.log('[VOTING_BOARDS_GET]', {
    url: req.url,
    method: req.method,
    params: Object.fromEntries(searchParams.entries()),
    headers: Object.fromEntries(req.headers.entries())
  });
  try {
    // Parse query parameters
    const visibility = searchParams.get("visibility") as VotingBoardVisibility | null;
    const openForVoting = searchParams.has("open_for_voting") ? searchParams.get("open_for_voting") === "true" : undefined;
    const published = searchParams.has("published") ? searchParams.get("published") === "true" : undefined;
    const userId = searchParams.get("user_id");

    // Build where clause with only defined parameters
    const where: Prisma.VotingBoardWhereInput = {};

    if (visibility) where.visibility = visibility;
    if (openForVoting !== undefined) where.openForVoting = openForVoting;
    if (published !== undefined) where.published = published;
    if (userId) where.userId = userId;

    // Check auth only for non-public boards
    if (visibility !== "public") {
      const session = await auth();
      if (!session?.user) {
        return new NextResponse("Unauthorized", { status: 401 });
      }
      // If no specific user requested, default to current user
      if (!userId) {
        where.userId = session.user.id;
      }
    }

    console.log('[VOTING_BOARDS_GET] WHERE', { where });
    const boards = await db.votingBoard.findMany({
      where,
      include: {
        items: {
          include: {
            _count: {
              select: {
                votes: true
              }
            }
          }
        },
        _count: {
          select: {
            items: true,
            comments: true,
          }
        }
      }
    }) as BoardWithRelations[];

    // Calculate stats for each board
    const boardsWithStats = boards.map((board) => {
      const totalVotes = board.items.reduce((sum, item) => sum + item._count.votes, 0);
      const topVotedItem = board.items.length > 0
        ? board.items.reduce((top, item) =>
          item._count.votes > (top?._count.votes ?? -1) ? item : top
        )
        : null;

      return {
        ...board,
        items: undefined, // Remove items from response to reduce payload size
        stats: {
          totalItems: board._count.items,
          totalVotes,
          totalComments: board._count.comments,
          isActive: board.published &&
            (!board.votingEndsAt || new Date(board.votingEndsAt) > new Date()) &&
            (!board.votingPausedAt || (board.votingPauseUntil && new Date(board.votingPauseUntil) < new Date())),
          topVotedItem: topVotedItem ? {
            title: topVotedItem.title,
            votes: topVotedItem._count.votes,
          } : undefined,
        },
      };
    });

    return NextResponse.json(boardsWithStats);
  } catch (error) {
    console.error("[VOTING_BOARDS_GET]", error);
    return new NextResponse(
      JSON.stringify({ error: "Failed to fetch voting boards" }),
      { status: 500 }
    );
  }
} 