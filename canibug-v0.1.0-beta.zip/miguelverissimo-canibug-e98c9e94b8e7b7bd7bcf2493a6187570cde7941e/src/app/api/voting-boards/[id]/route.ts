import { db } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { NextRequest, NextResponse } from "next/server";
import { VotingBoard, VotingItem, VotingItemVote } from "@prisma/client";

type VotingBoardWithRelations = VotingBoard & {
  _count: {
    items: number;
    comments: number;
  };
  items: (VotingItem & {
    _count: {
      votes: number;
      VotingItemComment: number;
    };
    votes: VotingItemVote[];
  })[];
};

type VotingItemWithStats = VotingItem & {
  stats: {
    totalVotes: number;
    totalComments: number;
    score: number;
  };
};

type VotingBoardResponse = VotingBoardWithRelations & {
  stats: {
    totalItems: number;
    totalVotes: number;
    totalComments: number;
    isActive: boolean;
    topVotedItem?: {
      title: string;
      votes: number;
    };
  };
  items: VotingItemWithStats[];
};

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const boardId = (await params).id;
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const board = await db.votingBoard.findUnique({
      where: {
        id: boardId,
      },
      include: {
        _count: {
          select: {
            items: true,
            comments: true,
          },
        },
        items: {
          include: {
            _count: {
              select: {
                votes: true,
                VotingItemComment: true,
              },
            },
            votes: true,
          },
          orderBy: {
            createdAt: "desc",
          },
        },
      },
    }) as VotingBoardWithRelations | null;

    if (!board) {
      return new NextResponse("Board not found", { status: 404 });
    }

    const now = new Date();
    const isActive = Boolean(
      board.published &&
      (!board.votingEndsAt || board.votingEndsAt > now) &&
      (!board.votingPausedAt || (board.votingPauseUntil && board.votingPauseUntil > now))
    );

    // Calculate board stats
    const stats = {
      totalItems: board._count.items,
      totalVotes: board.items.reduce((acc: number, item) => acc + item._count.votes, 0),
      totalComments: board._count.comments,
      isActive,
      topVotedItem: board.items.length > 0
        ? {
          title: board.items.reduce((max, item) =>
            item._count.votes > max._count.votes ? item : max
            , board.items[0]).title,
          votes: Math.max(...board.items.map(item => item._count.votes))
        }
        : undefined
    };

    // Transform items to include stats
    const transformedItems = board.items.map(item => ({
      ...item,
      stats: {
        totalVotes: item._count.votes,
        totalComments: item._count.VotingItemComment,
        score: item._count.votes + (item.boostBy || 0),
      }
    }));

    const response: VotingBoardResponse = {
      ...board,
      items: transformedItems,
      stats,
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error("[VOTING_BOARD_GET]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await request.json();
    const board = await db.votingBoard.update({
      where: {
        id: (await params).id,
      },
      data: {
        name: body.name,
        visibility: body.visibility,
        openForVoting: body.openForVoting,
        openForNewItems: body.openForNewItems,
        votersCanAddItems: body.votersCanAddItems,
        published: body.published,
        votingStartsAt: body.votingStartsAt,
        votingEndsAt: body.votingEndsAt,
        votingPausedAt: body.votingPausedAt,
        votingPauseUntil: body.votingPauseUntil,
      },
      include: {
        _count: {
          select: {
            items: true,
            comments: true,
          },
        },
        items: {
          include: {
            _count: {
              select: {
                votes: true,
                VotingItemComment: true,
              },
            },
            votes: true,
          },
        },
      },
    }) as VotingBoardWithRelations;

    const now = new Date();
    const isActive = Boolean(
      board.published &&
      (!board.votingEndsAt || board.votingEndsAt > now) &&
      (!board.votingPausedAt || (board.votingPauseUntil && board.votingPauseUntil > now))
    );

    // Calculate board stats
    const stats = {
      totalItems: board._count.items,
      totalVotes: board.items.reduce((acc: number, item) => acc + item._count.votes, 0),
      totalComments: board._count.comments,
      isActive,
      topVotedItem: board.items.length > 0
        ? {
          title: board.items.reduce((max, item) =>
            item._count.votes > max._count.votes ? item : max
            , board.items[0]).title,
          votes: Math.max(...board.items.map(item => item._count.votes))
        }
        : undefined
    };

    // Transform items to include stats
    const transformedItems = board.items.map(item => ({
      ...item,
      stats: {
        totalVotes: item._count.votes,
        totalComments: item._count.VotingItemComment,
        score: item._count.votes + (item.boostBy || 0),
      }
    }));

    const response: VotingBoardResponse = {
      ...board,
      items: transformedItems,
      stats,
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error("[VOTING_BOARD_PATCH]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    await db.votingBoard.delete({
      where: {
        id: (await params).id,
      },
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("[VOTING_BOARD_DELETE]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
} 