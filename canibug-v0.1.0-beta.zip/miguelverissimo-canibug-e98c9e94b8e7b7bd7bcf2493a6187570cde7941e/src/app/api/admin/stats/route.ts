import { db } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const now = new Date();
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
    const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [
      totalUsers,
      lastMonthUsers,
      lastWeekNewUsers,
      activeSubscriptions,
      lastWeekActiveSubscriptions
    ] = await Promise.all([
      // Total users
      db.user.count(),
      // Users last month
      db.user.count({
        where: {
          createdAt: {
            lt: lastMonth
          }
        }
      }),
      // New users this month
      db.user.count({
        where: {
          createdAt: {
            gte: lastMonth
          }
        }
      }),
      // New users last week
      db.user.count({
        where: {
          createdAt: {
            gte: lastWeek
          }
        }
      }),
      // Active subscriptions
      db.user.count({
        where: {
          subscriptionStatus: 'active'
        }
      }),
      // Active subscriptions last week
      db.user.count({
        where: {
          subscriptionStatus: 'active',
          updatedAt: {
            lt: lastWeek
          }
        }
      })
    ]);

    // Calculate percentages and changes
    const monthlyGrowth = totalUsers > 0
      ? ((totalUsers - lastMonthUsers) / lastMonthUsers * 100).toFixed(1)
      : "0";

    const weeklyNewUsers = lastWeekNewUsers;
    const weeklyNewUsersPercentage = totalUsers > 0
      ? ((weeklyNewUsers / totalUsers) * 100).toFixed(1)
      : "0";

    const activeSubscriptionPercentage = totalUsers > 0
      ? ((activeSubscriptions / totalUsers) * 100).toFixed(1)
      : "0";

    const subscriptionGrowth = lastWeekActiveSubscriptions > 0
      ? ((activeSubscriptions - lastWeekActiveSubscriptions) / lastWeekActiveSubscriptions * 100).toFixed(1)
      : "0";

    return NextResponse.json({
      totalUsers: {
        value: totalUsers,
        change: monthlyGrowth,
        trend: Number(monthlyGrowth) >= 0 ? "up" : "down"
      },
      newUsers: {
        value: weeklyNewUsers,
        percentage: weeklyNewUsersPercentage,
        trend: Number(weeklyNewUsersPercentage) >= 0 ? "up" : "down"
      },
      activeSubscriptions: {
        value: activeSubscriptionPercentage,
        change: subscriptionGrowth,
        trend: Number(subscriptionGrowth) >= 0 ? "up" : "down"
      }
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    return NextResponse.json(
      { error: "Failed to fetch admin stats" },
      { status: 500 }
    );
  }
} 