import { db } from "@/lib/prisma";
import { User } from "@/types/user";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const id = (await params).id;

  try {
    const user = await db.user.findUnique({
      where: { id },
      include: {
        settings: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    const serializedUser = new User({ ...user, settings: user.settings }).toJSON();
    return NextResponse.json(serializedUser);
  } catch (error) {
    console.error("Error fetching user:", error);
    return NextResponse.json(
      { error: "Failed to fetch user" },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const id = (await params).id;

  try {
    const data = await request.json();
    const { settings, ...updateData } = data;

    // Remove computed/readonly properties
    delete updateData.id;
    delete updateData.isSubscribed;

    // Update user data
    const updatedUser = await db.user.update({
      where: { id },
      data: {
        ...updateData,
        settings: settings ? {
          upsert: {
            create: {
              data: settings.data
            },
            update: {
              data: settings.data
            }
          }
        } : undefined
      },
      include: {
        settings: true,
      },
    });

    const serializedUser = new User({ ...updatedUser, settings: updatedUser.settings }).toJSON();
    return NextResponse.json(serializedUser);
  } catch (error) {
    console.error("Error updating user:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update user" },
      { status: 500 }
    );
  }
} 