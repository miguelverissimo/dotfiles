import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { User } from "@/types/user";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: {
        settings: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    const serializedUser = new User({ ...user, settings: user.settings }).toJSON();
    return NextResponse.json(serializedUser);
  } catch (error) {
    console.error("Error fetching profile:", error);
    return NextResponse.json(
      { error: "Failed to fetch profile" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const data = await request.json();
    const { settings, ...userData } = data;

    // Update user data
    const updatedUser = await db.user.update({
      where: { id: session.user.id },
      data: {
        ...userData,
        settings: settings ? {
          upsert: {
            create: {
              data: settings.data
            },
            update: {
              data: settings.data
            }
          }
        } : undefined
      },
      include: {
        settings: true,
      },
    });

    const serializedUser = new User({ ...updatedUser, settings: updatedUser.settings }).toJSON();
    return NextResponse.json(serializedUser);
  } catch (error) {
    console.error("Error updating profile:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update profile" },
      { status: 500 }
    );
  }
} 