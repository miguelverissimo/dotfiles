import { db } from "@/lib/prisma";

type PublicBoardPageProps = {
  params: Promise<{
    id: string;
  }>;
};

async function getBoard(id: string) {
  const board = await db.votingBoard.findUnique({
    where: {
      id,
      published: true,
    },
  });

  return board;
}

export default async function PublicBoardPage({ params }: PublicBoardPageProps) {
  // https://nextjs.org/docs/messages/sync-dynamic-apis
  const { id } = await params;

  const board = await getBoard(id);

  if (!board) {
    return <div>Board not found</div>;
  }

  return <div>Public Board Page {id}</div>;
}
