import Navbar from "@/features/dashboard/components/navbar";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";

async function LayoutPrivate({ children }: { children: React.ReactNode }) {
  const session = await auth();

  if (!session?.user) {
    redirect("/api/auth/signin");
  }

  return (
    <main className="bg-base-200 min-h-screen">
      <Navbar />
      {children}
    </main>
  );
}

export default LayoutPrivate;
