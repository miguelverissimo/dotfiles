import BoardCardLink from "@/features/boards/components/board-card-link";
import DeleteBoardButton from "@/features/boards/components/delete-board-button";
import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { ChevronLeftIcon } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";

async function getBoard(id: string, userId: string) {
  const board = await db.votingBoard.findUnique({
    where: {
      id,
      userId,
    },
  });

  return board;
}

type PrivateBoardPageProps = {
  params: Promise<{
    id: string;
  }>;
};

export default async function PrivateBoardPage({ params }: PrivateBoardPageProps) {
  const session = await auth();

  if (!session) {
    return redirect("/");
  }

  // https://nextjs.org/docs/messages/sync-dynamic-apis
  const { id } = await params;

  const board = await getBoard(id, session.user?.id as string);

  if (!board) {
    return redirect("/dashboard");
  }

  return (
    <main>
      <section className="max-w-5xl mx-auto px-5 py-3 flex justify-between items-center">
        <Link
          href="/dashboard"
          className="text-base-content text-xl flex items-center gap-2 hover:text-primary duration-200"
        >
          <ChevronLeftIcon className="w-6 h-6" />
          <span>Back to Dashboard</span>
        </Link>
      </section>

      <section className="max-w-5xl mx-auto px-5 py-12 space-y-12">
        <h1 className="text-xl font-extrabold mb-4">{board.name}</h1>

        <BoardCardLink boardId={board.id} />
        <DeleteBoardButton boardId={board.id} />
      </section>
    </main>
  );
};

