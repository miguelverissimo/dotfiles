import NewBoardForm from "@/features/boards/components/new-board-form";
import { auth } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { Session } from "next-auth";
import Link from "next/link";
import { redirect } from "next/navigation";

async function getUser(session: Session) {
  const user = await db.user.findUnique({
    where: {
      id: session.user?.id as string,
    },
    include: {
      boards: true,
    },
  });

  return user;
}

export default async function DashboardPage() {
  const session = await auth();

  if (!session) {
    return redirect("/");
  }

  const user = await getUser(session);

  return (
    <section className="max-w-5xl mx-auto px-5 py-12 space-y-12">
      <NewBoardForm />

      <div>
        <h1 className="text-xl font-extrabold mb-4">
          {user?.boards.length} Boards
        </h1>

        <ul className="space-y-4">
          {user?.boards.map((board) => (
            <li
              key={board.id}
            >
              <Link
                href={`/dashboard/boards/${board.id}`}
                className="block bg-base-100 p-6 rounded-3xl hover:bg-neutral hover:text-neutral-content duration-200"
              >
                <p className="text-xl font-extrabold">{board.name}</p>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
