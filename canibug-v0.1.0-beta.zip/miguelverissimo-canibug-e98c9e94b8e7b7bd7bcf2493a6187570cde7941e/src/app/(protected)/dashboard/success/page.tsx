import { auth } from "@/lib/auth";
import Link from "next/link";
import { redirect } from "next/navigation";
import ConfettiBlast from "@/components/confetti-blast";
export default async function SuccessPage() {
  const session = await auth();

  if (!session) {
    return redirect('/');
  }

  return (
    <main className="min-h-screen flex flex-col justify-center items-center gap-8">
      <ConfettiBlast />

      <h1 className="text-xl font-bold">Thank you for subscribing! ❤️</h1>
      <Link href="/dashboard" className="btn btn-primary">
        Go back to dashboard and start using the app!
      </Link>
    </main>
  );
};