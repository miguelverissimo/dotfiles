'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell, Check, Loader2, Moon, Pencil, User, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';

interface ProfileSettings {
  emailNotifications?: boolean;
  pushNotifications?: boolean;
  theme?: 'light' | 'dark' | 'system';
  emailDigest?: 'daily' | 'weekly' | 'never';
  marketingEmails?: boolean;
  language?: string;
  displayName?: string;
}

interface ProfileData {
  id: string;
  displayName: string | null;
  settings: {
    data: Partial<ProfileSettings>;
  };
}

type SettingKey = keyof ProfileSettings;

async function fetchProfile(): Promise<ProfileData> {
  const response = await fetch('/api/me');
  if (!response.ok) {
    throw new Error('Failed to fetch profile');
  }
  return response.json();
}

async function updateProfile(data: {
  settings: {
    data: Partial<ProfileSettings>;
  };
}) {
  const response = await fetch('/api/me', {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error('Failed to update settings');
  }
  return response.json();
}

export default function SettingsPage() {
  const queryClient = useQueryClient();
  const [updatingKey, setUpdatingKey] = useState<SettingKey | 'displayName' | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [isEditingName, setIsEditingName] = useState(false);

  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile'],
    queryFn: fetchProfile,
  });

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.settings?.data?.displayName || '');
    }
  }, [profile]);

  const updateSettingsMutation = useMutation({
    mutationFn: updateProfile,
    onSuccess: (data) => {
      queryClient.setQueryData(['profile'], data);
      queryClient.invalidateQueries({ queryKey: ['user'] });
      toast.success('Settings updated successfully');
      setUpdatingKey(null);
      setIsEditingName(false);
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : 'Failed to update settings');
      setUpdatingKey(null);
      setIsEditingName(false);
    },
  });

  const handleSettingChange = (key: SettingKey, value: ProfileSettings[SettingKey]) => {
    const currentSettings = profile?.settings?.data || {};
    setUpdatingKey(key);
    updateSettingsMutation.mutate({
      settings: {
        data: {
          ...currentSettings,
          [key]: value
        }
      }
    });
  };

  const handleDisplayNameSave = () => {
    if (!profile) return;
    const currentSettings = profile.settings?.data || {};
    setUpdatingKey('displayName');
    updateSettingsMutation.mutate({
      settings: {
        data: {
          ...currentSettings,
          displayName
        }
      }
    });
  };

  const handleDisplayNameCancel = () => {
    setIsEditingName(false);
    setDisplayName(profile?.settings?.data?.displayName || '');
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="loading loading-spinner loading-lg" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="text-error text-lg font-semibold">Failed to load settings</div>
        <div className="text-sm text-base-content/70">
          Please try again later
        </div>
      </div>
    );
  }

  const settings = profile.settings?.data || {};

  const renderDisplayName = () => {
    const isUpdating = updatingKey === 'displayName';

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <User className="w-5 h-5" />
          <h3 className="text-lg font-medium">Profile</h3>
        </div>
        <div className="divider my-2"></div>

        <div className="flex items-center gap-3 p-4 bg-base-200 rounded-lg">
          <User className="w-5 h-5 text-base-content/70" />
          <div className="flex-grow">
            <p className="text-sm text-base-content/70">Display Name</p>
            {isEditingName ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (displayName.trim()) {
                    handleDisplayNameSave();
                  }
                }}
                className="flex gap-2 items-center mt-1"
              >
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="input input-sm input-bordered flex-grow"
                  placeholder="Enter your display name"
                  disabled={isUpdating}
                  autoFocus
                />
                <button
                  type="submit"
                  className="btn btn-sm btn-circle btn-success"
                  disabled={isUpdating || !displayName.trim()}
                  aria-label="Save"
                >
                  {isUpdating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Check className="w-4 h-4" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleDisplayNameCancel}
                  className="btn btn-sm btn-circle btn-error"
                  disabled={isUpdating}
                  aria-label="Cancel"
                >
                  <X className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <div className="flex items-center gap-2">
                <p className="font-medium">{profile.settings?.data?.displayName || 'Not set'}</p>
                <button
                  onClick={() => setIsEditingName(true)}
                  className="btn btn-sm btn-circle btn-ghost"
                  disabled={updateSettingsMutation.isPending}
                  aria-label="Edit display name"
                >
                  <Pencil className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderToggle = (
    key: SettingKey,
    label: string,
    description: string
  ) => {
    const isUpdating = updatingKey === key;

    return (
      <div className="form-control">
        <label className="label cursor-pointer justify-start gap-4">
          <div className="w-12 flex justify-center">
            {isUpdating ? (
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            ) : (
              <input
                type="checkbox"
                className="toggle toggle-primary"
                checked={!!settings[key]}
                disabled={updateSettingsMutation.isPending}
                onChange={(e) => handleSettingChange(key, e.target.checked as ProfileSettings[SettingKey])}
              />
            )}
          </div>
          <div className="flex-1">
            <p className="font-medium">{label}</p>
            <p className="text-sm text-base-content/70">{description}</p>
          </div>
        </label>
      </div>
    );
  };

  const renderSelect = (
    key: SettingKey,
    label: string,
    options: { value: string; label: string }[],
    defaultValue: string
  ) => {
    const isUpdating = updatingKey === key;

    return (
      <div className="form-control w-full max-w-xs">
        <label className="label">
          <span className="label-text font-medium">{label}</span>
          {isUpdating && (
            <Loader2 className="w-4 h-4 animate-spin text-primary ml-2" />
          )}
        </label>
        <select
          className="select select-bordered w-full"
          value={String(settings[key] ?? defaultValue)}
          disabled={updateSettingsMutation.isPending}
          onChange={(e) => handleSettingChange(key, e.target.value as ProfileSettings[SettingKey])}
        >
          {options.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    );
  };

  return (
    <div className="container mx-auto p-6">
      <div className="card bg-base-100 shadow-xl max-w-3xl mx-auto">
        <div className="card-body">
          <h2 className="card-title text-2xl font-bold">Settings</h2>
          <p className="text-base-content/70">Manage your account settings and preferences.</p>

          <div className="space-y-8 mt-6">
            {/* Display Name Section */}
            {renderDisplayName()}

            {/* Notifications Section */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                <h3 className="text-lg font-medium">Notifications</h3>
              </div>
              <div className="divider my-2"></div>

              {renderToggle(
                'emailNotifications',
                'Email Notifications',
                'Receive notifications about your account via email.'
              )}

              {renderToggle(
                'marketingEmails',
                'Marketing Emails',
                'Receive emails about new features and promotions.'
              )}

              {renderToggle(
                'pushNotifications',
                'Push Notifications',
                'Receive push notifications on your device.'
              )}
            </div>

            {/* Preferences Section */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Moon className="w-5 h-5" />
                <h3 className="text-lg font-medium">Preferences</h3>
              </div>
              <div className="divider my-2"></div>

              {renderSelect(
                'theme',
                'Theme',
                [
                  { value: 'light', label: 'Light' },
                  { value: 'dark', label: 'Dark' },
                  { value: 'system', label: 'System' }
                ],
                'system'
              )}

              {renderSelect(
                'emailDigest',
                'Email Digest',
                [
                  { value: 'daily', label: 'Daily' },
                  { value: 'weekly', label: 'Weekly' },
                  { value: 'never', label: 'Never' }
                ],
                'never'
              )}

              {renderSelect(
                'language',
                'Language',
                [
                  { value: 'english', label: 'English' },
                  { value: 'spanish', label: 'Spanish' },
                  { value: 'french', label: 'French' },
                  { value: 'german', label: 'German' }
                ],
                'english'
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}