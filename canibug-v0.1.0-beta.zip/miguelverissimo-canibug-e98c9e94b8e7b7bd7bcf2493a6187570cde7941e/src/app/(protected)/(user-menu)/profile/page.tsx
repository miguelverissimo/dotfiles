'use client';

import { Camera, Check, Github, Loader2, Mail, Pencil, User, X } from "lucide-react";
import Image from "next/image";
import { useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";

async function fetchProfile() {
  const response = await fetch('/api/me');
  if (!response.ok) {
    throw new Error('Failed to fetch profile');
  }
  return response.json();
}

async function updateProfile(data: Partial<{
  name: string | null;
  email: string | null;
  image: string | null;
  settings: {
    data: {
      githubUsername?: string;
      [key: string]: unknown;
    };
  };
}>) {
  const response = await fetch('/api/me', {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error('Failed to update profile');
  }
  return response.json();
}

export default function ProfilePage() {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [editing, setEditing] = useState<'name' | 'email' | 'github' | 'avatar' | null>(null);
  const [editValue, setEditValue] = useState('');

  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['profile'],
    queryFn: fetchProfile,
  });

  const updateProfileMutation = useMutation({
    mutationFn: updateProfile,
    onSuccess: (data) => {
      queryClient.setQueryData(['profile'], data);
      queryClient.setQueryData(['user'], data);
      toast.success('Profile updated successfully');
      setEditing(null);
      setEditValue('');
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : 'Failed to update profile');
      setEditing(null);
    },
  });

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setEditing('avatar');
      const reader = new FileReader();
      reader.onloadend = () => {
        updateProfileMutation.mutate({
          image: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const startEditing = (field: 'name' | 'email' | 'github', value: string) => {
    setEditing(field);
    setEditValue(value.replace(/^@/, '')); // Remove @ from github username when editing
  };

  const cancelEditing = () => {
    setEditing(null);
    setEditValue('');
  };

  const saveEdit = () => {
    if (!editing || !profile) return;

    switch (editing) {
      case 'name':
        updateProfileMutation.mutate({ name: editValue });
        break;
      case 'email':
        updateProfileMutation.mutate({ email: editValue });
        break;
      case 'github':
        updateProfileMutation.mutate({
          settings: {
            data: {
              ...profile.settings?.data,
              githubUsername: editValue
            }
          }
        });
        break;
    }
  };

  const renderEditableField = (
    field: 'name' | 'email' | 'github',
    icon: React.ReactNode,
    label: string,
    value: string
  ) => {
    const isEditing = editing === field;
    const isUpdating = updateProfileMutation.isPending;
    const isFieldUpdating = isUpdating && editing === field;

    return (
      <div className="flex items-center gap-3 p-4 bg-base-200 rounded-lg">
        {icon}
        <div className="flex-grow">
          <p className="text-sm text-base-content/70">{label}</p>
          {isEditing ? (
            <div className="flex gap-2 items-center mt-1">
              <input
                type="text"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                className="input input-sm input-bordered flex-grow"
                disabled={isFieldUpdating}
                autoFocus
              />
              <button
                onClick={saveEdit}
                className="btn btn-sm btn-circle btn-success"
                disabled={isFieldUpdating}
                aria-label="Save"
              >
                {isFieldUpdating ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={cancelEditing}
                className="btn btn-sm btn-circle btn-error"
                disabled={isFieldUpdating}
                aria-label="Cancel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {isUpdating && editing === field ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-base-content/70">Updating...</span>
                </div>
              ) : (
                <>
                  <p className="font-medium">{value}</p>
                  <button
                    onClick={() => startEditing(field, value)}
                    className="btn btn-sm btn-circle btn-ghost"
                    disabled={isUpdating}
                    aria-label={`Edit ${label.toLowerCase()}`}
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  if (isLoadingProfile) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="loading loading-spinner loading-lg" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="text-error text-lg font-semibold">Failed to load profile</div>
        <div className="text-sm text-base-content/70">
          Please try again later
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="card bg-base-100 shadow-xl max-w-2xl mx-auto">
        <div className="card-body">
          <h2 className="card-title text-2xl font-bold mb-6">Profile</h2>

          <div className="flex flex-col items-center gap-6">
            <div className="relative group">
              <div className="avatar">
                <div className="w-32 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
                  {editing === 'avatar' ? (
                    <div className="w-full h-full flex items-center justify-center bg-base-200">
                      <Loader2 className="w-8 h-8 animate-spin" />
                    </div>
                  ) : (
                    <Image
                      src={profile.image || '/default-avatar.png'}
                      alt={profile.name || 'User'}
                      width={128}
                      height={128}
                    />
                  )}
                </div>
              </div>
              <button
                onClick={handleAvatarClick}
                disabled={editing === 'avatar'}
                className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity disabled:bg-black/70"
                aria-label="Change profile picture"
              >
                {editing === 'avatar' ? (
                  <Loader2 className="w-6 h-6 text-white animate-spin" />
                ) : (
                  <Camera className="w-6 h-6 text-white" />
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
                aria-label="Upload profile picture"
                disabled={editing === 'avatar'}
              />
            </div>

            <div className="w-full space-y-4">
              {renderEditableField(
                'name',
                <User className="w-5 h-5 text-base-content/70" />,
                'Name',
                profile.name || 'Unnamed User'
              )}

              {renderEditableField(
                'email',
                <Mail className="w-5 h-5 text-base-content/70" />,
                'Email',
                profile.email || 'No email set'
              )}

              {renderEditableField(
                'github',
                <Github className="w-5 h-5 text-base-content/70" />,
                'GitHub',
                profile.settings?.data?.githubUsername ? `@${profile.settings.data.githubUsername}` : 'Not connected'
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}