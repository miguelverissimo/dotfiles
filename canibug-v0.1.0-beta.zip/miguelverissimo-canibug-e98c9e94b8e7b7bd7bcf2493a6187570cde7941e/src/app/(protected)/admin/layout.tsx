import NavigationPane from "@/features/admin/components/navigation-pane";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";

async function LayoutAdmin({ children }: { children: React.ReactNode }) {
  const session = await auth();

  if (!session?.user) {
    redirect("/api/auth/signin");
  }

  return (
    <main className="bg-base-200 min-h-screen">
      <NavigationPane>
        {children}
      </NavigationPane>
    </main>
  );
}

export default LayoutAdmin;
