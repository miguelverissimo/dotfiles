"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Form, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectItem } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useVotingBoard, useUpdateVotingBoard } from "@/hooks/use-voting-board";
import { useVotingItems } from "@/hooks/use-voting-item";
import { updateVotingBoardSchema } from "@/schemas/voting";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Save, X, Plus } from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { DateTimePicker } from "@/components/ui/date-time-picker";
import toast from "react-hot-toast";
import { VotingItemsTable } from "@/features/admin/boards/components/voting-items-table";
import { VotingItemForm } from "@/features/admin/boards/components/voting-item-form";

type FormValues = z.infer<typeof updateVotingBoardSchema>;

export default function BoardDetailPage() {
  const router = useRouter();
  const boardId = useParams().id as string;

  const { data: board, isLoading: isBoardLoading } = useVotingBoard(boardId);
  const { data: items, isLoading: isItemsLoading } = useVotingItems({ boardId });
  const updateBoard = useUpdateVotingBoard();
  const [isAddingItem, setIsAddingItem] = React.useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(updateVotingBoardSchema),
    defaultValues: {
      name: "",
      visibility: "private",
      openForVoting: false,
      openForNewItems: false,
      votersCanAddItems: false,
      published: false,
      votingStartsAt: null,
      votingEndsAt: null,
    },
  });

  // Update form when board data is loaded
  React.useEffect(() => {
    if (board) {
      form.reset({
        name: board.name,
        visibility: board.visibility,
        openForVoting: board.openForVoting,
        openForNewItems: board.openForNewItems,
        votersCanAddItems: board.votersCanAddItems,
        published: board.published,
        votingStartsAt: board.votingStartsAt || null,
        votingEndsAt: board.votingEndsAt || null,
      });
    }
  }, [board, form]);

  const onSubmit = async (data: FormValues) => {
    try {
      await updateBoard.mutateAsync({
        id: boardId,
        ...data,
      });
      toast.success('Board updated successfully');
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to update board: ${message}`);
      console.error("Failed to update board:", error);
    }
  };

  if (isBoardLoading) {
    return <BoardDetailSkeleton />;
  }

  if (!board) {
    return (
      <div className="p-6">
        <div className="text-center text-error">Board not found</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.back()}
            className="btn-circle"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">Board Details</h1>
        </div>
        <div className="space-x-2">
          <Button
            className="btn btn-primary gap-2"
            type="submit"
            form="board-form"
            disabled={!form.formState.isDirty || updateBoard.isPending}
          >
            {updateBoard.isPending ? (
              <span className="loading loading-spinner loading-sm" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            Save Changes
          </Button>
          <Button
            variant="ghost"
            onClick={() => router.push('/admin/boards')}
          >
            <X className="w-4 h-4" />
            Cancel
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <Form {...form}>
          <form id="board-form" onSubmit={form.handleSubmit(onSubmit)}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Board Information */}
              <section className="card bg-base-100 shadow-lg">
                <div className="card-body">
                  <h2 className="card-title mb-6">Board Information</h2>
                  <div className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <div>
                          <label className="text-sm font-medium">Name</label>
                          <Input
                            className="input input-bordered w-full mt-1"
                            placeholder="Enter board name"
                            {...field}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="visibility"
                      render={({ field }) => (
                        <div>
                          <label className="text-sm font-medium">Visibility</label>
                          <Select
                            value={field.value}
                            onChange={(e: React.ChangeEvent<HTMLSelectElement>) => field.onChange(e.target.value)}
                          >
                            <SelectItem value="public">Public</SelectItem>
                            <SelectItem value="private">Private</SelectItem>
                            <SelectItem value="restricted">Restricted</SelectItem>
                            <SelectItem value="focusGroup">Focus Group</SelectItem>
                            <SelectItem value="innerCircle">Inner Circle</SelectItem>
                          </Select>
                        </div>
                      )}
                    />
                  </div>
                </div>
              </section>

              {/* Board Settings */}
              <section className="card bg-base-100 shadow-lg">
                <div className="card-body">
                  <h2 className="card-title mb-6">Board Settings</h2>
                  <div className="space-y-2">
                    <FormField
                      control={form.control}
                      name="published"
                      render={({ field }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Published</div>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="openForVoting"
                      render={({ field }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Open for Voting</div>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="openForNewItems"
                      render={({ field }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Open for New Items</div>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="votersCanAddItems"
                      render={({ field }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Voters Can Add Items</div>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="votingStartsAt"
                      render={({ field: { value, onChange, ...field } }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Voting Start Date</div>
                          <DateTimePicker
                            value={value || null}
                            onChange={(date) => {
                              onChange(date);
                            }}
                            {...field}
                          />
                        </div>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="votingEndsAt"
                      render={({ field: { value, onChange, ...field } }) => (
                        <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                          <div>Voting End Date</div>
                          <DateTimePicker
                            value={value || null}
                            onChange={(date) => {
                              onChange(date);
                            }}
                            {...field}
                          />
                        </div>
                      )}
                    />
                  </div>
                </div>
              </section>
            </div>
          </form>
        </Form>

        {/* Items Table */}
        <section className="card bg-base-100 shadow-lg">
          <div className="card-body">
            <div className="flex justify-between items-center mb-6">
              <h2 className="card-title">Items</h2>
              <Button
                size="sm"
                className="btn btn-primary btn-sm gap-2"
                onClick={() => setIsAddingItem(true)}
                disabled={isAddingItem}
              >
                <Plus className="w-4 h-4" />
                Add Item
              </Button>
            </div>

            {isAddingItem ? (
              <VotingItemForm
                mode="create"
                boardId={boardId}
                onSuccess={() => {
                  setIsAddingItem(false);
                }}
                onCancel={() => {
                  setIsAddingItem(false);
                }}
              />
            ) : (
              <VotingItemsTable
                items={items}
                isLoading={isItemsLoading}
                onItemClick={(itemId) => {
                  // TODO: Navigate to item detail page
                  console.log('Navigate to item:', itemId);
                }}
              />
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

const BoardDetailSkeleton = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10 rounded-full" />
          <Skeleton className="h-8 w-48" />
        </div>
        <div className="space-x-2">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="card bg-base-100 shadow-lg">
          <div className="card-body space-y-4">
            <Skeleton className="h-6 w-32" />
            {Array.from({ length: 2 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </section>

        <section className="card bg-base-100 shadow-lg">
          <div className="card-body space-y-4">
            <Skeleton className="h-6 w-32" />
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </section>
      </div>

      <section className="card bg-base-100 shadow-lg">
        <div className="card-body">
          <div className="flex justify-between items-center mb-6">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-10 w-24" />
          </div>
          <ItemsTableSkeleton />
        </div>
      </section>
    </div>
  );
};

const ItemsTableSkeleton = () => {
  return (
    <div className="space-y-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-24" />
        </div>
      ))}
    </div>
  );
}; 