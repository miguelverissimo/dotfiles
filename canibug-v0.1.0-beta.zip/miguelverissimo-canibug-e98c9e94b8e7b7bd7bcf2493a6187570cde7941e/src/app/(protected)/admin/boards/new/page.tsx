"use client";

import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createVotingBoardSchema } from "@/schemas/voting";
import { useCreateVotingBoard } from "@/hooks/use-voting-board";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormField,
} from "@/components/ui/form";
import { Select, SelectItem } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { DateTimePicker } from "@/components/ui/date-time-picker";
import type { CreateVotingBoardInput } from "@/schemas/voting";
import { ArrowLeft, Save, X } from "lucide-react";
import toast from "react-hot-toast";

const NewBoardPage = () => {
  const router = useRouter();
  const { mutateAsync: createBoard, isLoading } = useCreateVotingBoard();

  const form = useForm<CreateVotingBoardInput>({
    resolver: zodResolver(createVotingBoardSchema),
    defaultValues: {
      name: "",
      visibility: "private",
      openForVoting: false,
      openForNewItems: true,
      votersCanAddItems: false,
      published: false,
      votingStartsAt: null,
      votingEndsAt: null,
    },
  });

  const onSubmit = async (data: CreateVotingBoardInput) => {
    try {
      await createBoard(data);
      toast.success('Board created successfully');
      router.push("/admin/boards");
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      toast.error(`Failed to create board: ${message}`);
      console.error("Failed to create board:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.back()}
            className="btn-circle"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">New Board</h1>
        </div>
        <div className="space-x-2">
          <Button
            className="btn btn-primary gap-2"
            type="submit"
            form="new-board-form"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="loading loading-spinner loading-sm" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            Save Changes
          </Button>
          <Button
            variant="ghost"
            onClick={() => router.push('/admin/boards')}
          >
            <X className="w-4 h-4" />
            Cancel
          </Button>
        </div>
      </div>

      <Form {...form}>
        <form id="new-board-form" onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Board Information */}
            <section className="card bg-base-100 shadow-lg">
              <div className="card-body">
                <h2 className="card-title mb-6">Board Information</h2>
                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <div>
                        <label className="text-sm font-medium">Name</label>
                        <Input
                          className="input input-bordered w-full mt-1"
                          placeholder="Enter board name"
                          {...field}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="visibility"
                    render={({ field }) => (
                      <div>
                        <label className="text-sm font-medium">Visibility</label>
                        <Select
                          value={field.value}
                          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => field.onChange(e.target.value)}
                        >
                          <SelectItem value="public">Public</SelectItem>
                          <SelectItem value="private">Private</SelectItem>
                          <SelectItem value="restricted">Restricted</SelectItem>
                          <SelectItem value="focusGroup">Focus Group</SelectItem>
                          <SelectItem value="innerCircle">Inner Circle</SelectItem>
                        </Select>
                      </div>
                    )}
                  />
                </div>
              </div>
            </section>

            {/* Board Settings */}
            <section className="card bg-base-100 shadow-lg">
              <div className="card-body">
                <h2 className="card-title mb-6">Board Settings</h2>
                <div className="space-y-2">
                  <FormField
                    control={form.control}
                    name="published"
                    render={({ field }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Published</div>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="openForVoting"
                    render={({ field }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Open for Voting</div>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="openForNewItems"
                    render={({ field }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Open for New Items</div>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="votersCanAddItems"
                    render={({ field }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Voters Can Add Items</div>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="votingStartsAt"
                    render={({ field: { value, onChange, ...field } }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Voting Start Date</div>
                        <DateTimePicker
                          value={value || null}
                          onChange={(date) => {
                            onChange(date);
                          }}
                          {...field}
                        />
                      </div>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="votingEndsAt"
                    render={({ field: { value, onChange, ...field } }) => (
                      <div className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                        <div>Voting End Date</div>
                        <DateTimePicker
                          value={value || null}
                          onChange={(date) => {
                            onChange(date);
                          }}
                          {...field}
                        />
                      </div>
                    )}
                  />
                </div>
              </div>
            </section>
          </div>
        </form>
      </Form>
    </div >
  );
};

export default NewBoardPage;

