"use client";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useVotingBoards } from "@/hooks/use-voting-board";
import { cn } from "@/lib/utils";
import { VotingBoardListItem } from "@/types/voting";
import { PlusCircle } from "lucide-react";
import { useRouter } from "next/navigation";

const AdminBoardsPage = () => {
  const router = useRouter();
  const { data: boards, isLoading } = useVotingBoards();

  console.log('Raw boards from API:', boards);

  // Separate boards into categories
  const categorizeBoards = (boards: VotingBoardListItem[] = []) => {
    const now = new Date();
    console.log('Current time:', now.toISOString());

    return {
      active: boards.filter(board => {
        console.log('\nProcessing board for active category:', {
          id: board.id,
          name: board.name,
          published: board.published,
          votingEndsAt: board.votingEndsAt ? new Date(board.votingEndsAt).toISOString() : null,
          votingPausedAt: board.votingPausedAt ? new Date(board.votingPausedAt).toISOString() : null,
          votingPauseUntil: board.votingPauseUntil ? new Date(board.votingPauseUntil).toISOString() : null
        });

        // Ensure all dates are properly converted to Date objects
        const endDate = board.votingEndsAt ? new Date(board.votingEndsAt) : null;
        const pauseUntilDate = board.votingPauseUntil ? new Date(board.votingPauseUntil) : null;
        const pausedAtDate = board.votingPausedAt ? new Date(board.votingPausedAt) : null;

        // Check if the board is active
        const isPublished = board.published;
        const isNotEnded = !endDate || endDate.getTime() > now.getTime();
        const isNotPaused = !pausedAtDate || (pauseUntilDate && pauseUntilDate.getTime() < now.getTime());

        const isActive = isPublished && isNotEnded && isNotPaused;

        console.log('Board activity conditions:', {
          name: board.name,
          isActive,
          conditions: {
            isPublished,
            isNotEnded,
            isNotPaused,
            details: {
              endDateCheck: endDate ? `ends in ${Math.floor((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))} days` : 'no end date',
              pauseCheck: pausedAtDate ? (pauseUntilDate ? `paused until ${pauseUntilDate.toISOString()}` : 'paused indefinitely') : 'not paused'
            }
          }
        });

        return isActive;
      }).sort((a, b) => (b.stats.totalVotes - a.stats.totalVotes)),

      finished: boards.filter(board => {
        const endDate = board.votingEndsAt ? new Date(board.votingEndsAt) : null;
        return board.published && endDate && endDate.getTime() <= now.getTime();
      }).sort((a, b) => (b.stats.totalVotes - a.stats.totalVotes)),

      unpublished: boards.filter(board =>
        !board.published
      ).sort((a, b) => {
        if (!a.votingStartsAt || !b.votingStartsAt) return 0;
        const startDateA = new Date(a.votingStartsAt).getTime();
        const startDateB = new Date(b.votingStartsAt).getTime();
        return startDateA - startDateB;
      })
    };
  };

  const { active, finished, unpublished } = categorizeBoards(boards);

  const getTimeDisplay = (board: VotingBoardListItem) => {
    if (!board.votingEndsAt) return "not timebound";
    const endDate = new Date(board.votingEndsAt);
    const now = new Date();
    const diff = endDate.getTime() - now.getTime();
    const days = Math.floor(Math.abs(diff) / (1000 * 60 * 60 * 24));
    const hours = Math.floor((Math.abs(diff) % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

    if (diff > 0) {
      return `${days}d ${hours}h remaining`;
    } else {
      return `finished ${days}d ${hours}h ago`;
    }
  };

  const BoardTable = ({
    boards,
    title,
    emptyMessage
  }: {
    boards: VotingBoardListItem[];
    title: string;
    emptyMessage: string;
  }) => {
    if (boards.length === 0) {
      return <EmptyState message={emptyMessage} />;
    }

    return (
      <div className="overflow-x-auto relative">
        <div className="mb-4">
          <h3 className="text-xl font-semibold">{title}</h3>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Visibility</th>
              <th>Total Votes</th>
              <th>Top Voted</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {boards.map(board => (
              <tr
                key={board.id}
                onClick={() => router.push(`/admin/boards/${board.id}`)}
                className="hover:bg-base-200 cursor-pointer"
              >
                <td>{board.name}</td>
                <td>
                  <div className={cn(
                    "badge",
                    {
                      "badge-success": board.visibility === "public",
                      "badge-warning": board.visibility === "restricted",
                      "badge-error": board.visibility === "private",
                      "badge-secondary": board.visibility === "focusGroup",
                      "badge-primary": board.visibility === "innerCircle",
                    }
                  )}>
                    {board.visibility}
                  </div>
                </td>
                <td>
                  <div className="badge badge-ghost">
                    {board.stats.totalVotes} votes
                  </div>
                </td>
                <td>
                  {board.stats.topVotedItem ? (
                    <div className="flex items-center gap-2">
                      <span>{board.stats.topVotedItem.title}</span>
                      <div className="badge badge-ghost">
                        {board.stats.topVotedItem.votes} votes
                      </div>
                    </div>
                  ) : (
                    <span className="text-muted-foreground">No items</span>
                  )}
                </td>
                <td className="text-muted-foreground">
                  {getTimeDisplay(board)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Voting Boards</h1>
        <Button
          onClick={() => router.push("/admin/boards/new")}
          className="flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Create New Board
        </Button>
      </div>

      {isLoading ? (
        <BoardListSkeleton />
      ) : (
        <div className="space-y-8">
          <BoardTable
            title="Active Boards"
            boards={active}
            emptyMessage="No active boards"
          />
          <BoardTable
            title="Finished Boards"
            boards={finished}
            emptyMessage="No finished boards"
          />
          <BoardTable
            title="Unpublished Boards"
            boards={unpublished}
            emptyMessage="No unpublished boards"
          />
        </div>
      )}
    </div>
  );
};

const EmptyState = ({ message }: { message: string }) => {
  return (
    <div className="text-center p-8 border rounded-lg bg-muted/50">
      <p className="text-muted-foreground">{message}</p>
    </div>
  );
};

const BoardListSkeleton = () => {
  return (
    <div className="space-y-8">
      {[1, 2, 3].map(section => (
        <section key={section}>
          <Skeleton className="h-8 w-48 mb-4" />
          <table className="table w-full">
            <tbody>
              {[1, 2, 3].map(row => (
                <tr key={row}>
                  <td><Skeleton className="h-4 w-48" /></td>
                  <td><Skeleton className="h-4 w-24" /></td>
                  <td><Skeleton className="h-4 w-24" /></td>
                  <td><Skeleton className="h-4 w-64" /></td>
                  <td><Skeleton className="h-4 w-32" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      ))}
    </div>
  );
};

export default AdminBoardsPage;