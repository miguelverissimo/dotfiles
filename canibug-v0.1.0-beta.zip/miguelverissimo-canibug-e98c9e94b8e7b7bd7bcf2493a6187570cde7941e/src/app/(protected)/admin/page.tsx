"use client";

import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, Loader2 } from "lucide-react";

interface AdminStats {
  totalUsers: {
    value: number;
    change: string;
    trend: "up" | "down";
  };
  newUsers: {
    value: number;
    percentage: string;
    trend: "up" | "down";
  };
  activeSubscriptions: {
    value: string;
    change: string;
    trend: "up" | "down";
  };
}

async function fetchAdminStats(): Promise<AdminStats> {
  const response = await fetch("/api/admin/stats");
  if (!response.ok) {
    throw new Error("Failed to fetch admin stats");
  }
  return response.json();
}

const StatCard = ({
  title,
  value,
  description,
  trend
}: {
  title: string;
  value: string | number;
  description: string;
  trend: "up" | "down";
}) => (
  <div className="card bg-base-100 shadow-xl">
    <div className="card-body p-6">
      <h3 className="text-sm font-medium text-base-content/70">{title}</h3>
      <div className="text-3xl font-bold mt-2">{value}</div>
      <div className={`text-sm flex items-center gap-1 mt-2 ${trend === "up" ? "text-success" : "text-error"
        }`}>
        {trend === "up" ? (
          <ArrowUp className="w-4 h-4" />
        ) : (
          <ArrowDown className="w-4 h-4" />
        )}
        {description}
      </div>
    </div>
  </div>
);

const AdminDashboard = () => {
  const { data: stats, isLoading, error } = useQuery<AdminStats>({
    queryKey: ["adminStats"],
    queryFn: fetchAdminStats,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="w-8 h-8 animate-spin opacity-70" />
      </div>
    );
  }

  if (error || !stats) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="text-error text-lg font-semibold">Failed to load stats</div>
        <div className="text-sm text-base-content/70">
          {error instanceof Error ? error.message : "Please try again later"}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-[1200px] mx-auto px-4">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          title="Total Users"
          value={stats.totalUsers.value.toLocaleString()}
          description={`${stats.totalUsers.change}% from last month`}
          trend={stats.totalUsers.trend}
        />

        <StatCard
          title="New Users"
          value={stats.newUsers.value.toLocaleString()}
          description={`${stats.newUsers.percentage}% of total users`}
          trend={stats.newUsers.trend}
        />

        <StatCard
          title="Active Subscriptions"
          value={`${stats.activeSubscriptions.value}%`}
          description={`${stats.activeSubscriptions.change}% from last week`}
          trend={stats.activeSubscriptions.trend}
        />
      </div>
    </div>
  );
};

export default AdminDashboard;