"use client";

import { useState, useEffect } from "react";
import { ArrowLeft, Save, X, Plus } from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { SerializedUser } from "@/types/user";
import toast from "react-hot-toast";
import { Button } from "@/components/ui/button";
import { Select, SelectItem } from "@/components/ui/select";

const toCamelCase = (str: string): string => {
  // First convert to kebab case (handles spaces, underscores, and existing kebab case)
  const kebabCase = str
    .trim()
    .toLowerCase()
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, chr) => chr.toUpperCase())
    .replace(/[^a-zA-Z0-9]/g, '');

  // Then ensure first character is lowercase
  return kebabCase.charAt(0).toLowerCase() + kebabCase.slice(1);
};

async function fetchUser(id: string): Promise<SerializedUser> {
  const response = await fetch(`/api/users/${id}`);
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to fetch user');
  }
  return response.json();
}

async function updateUser(id: string, data: Partial<SerializedUser>): Promise<SerializedUser> {
  // Remove computed properties before sending
  /* eslint-disable @typescript-eslint/no-unused-vars */
  const { isAdmin, isSubscribed, id: userId, ...updateData } = data;
  /* eslint-enable @typescript-eslint/no-unused-vars */

  const response = await fetch(`/api/users/${id}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updateData),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to update user');
  }
  return response.json();
}

export default function UserDetailPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { id } = useParams() as { id: string };
  const [isEditing, setIsEditing] = useState(false);
  const [newSettingKey, setNewSettingKey] = useState('');
  const [newSettingValue, setNewSettingValue] = useState('true');
  const [showNewSettingForm, setShowNewSettingForm] = useState(false);
  const [newSettingType, setNewSettingType] = useState<'string' | 'boolean' | 'number'>('boolean');

  const { data: user, isLoading, error } = useQuery({
    queryKey: ['user', id],
    queryFn: () => fetchUser(id),
  });

  const [editedUser, setEditedUser] = useState<SerializedUser | null>(null);

  // Initialize editedUser when user data is loaded
  useEffect(() => {
    if (user && !editedUser) {
      setEditedUser(user);
    }
  }, [user, editedUser]);

  const updateUserMutation = useMutation({
    mutationFn: (data: Partial<SerializedUser>) => updateUser(id, data),
    onSuccess: (updatedUser) => {
      queryClient.setQueryData(['user', id], updatedUser);
      queryClient.invalidateQueries({ queryKey: ['user'] });
      setIsEditing(false);
      toast.success('User updated successfully');
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : 'Failed to update user');
    },
  });

  const handleSettingToggle = (setting: string) => {
    if (!editedUser?.settings) return;
    const settingsData = editedUser.settings.data || {};
    setEditedUser({
      ...editedUser,
      settings: {
        ...editedUser.settings,
        data: {
          ...settingsData,
          [setting]: !settingsData[setting]
        }
      }
    });
  };

  const handleSettingChange = (key: string, value: string | boolean) => {
    if (!editedUser?.settings) return;
    const settingsData = editedUser.settings.data || {};
    setEditedUser({
      ...editedUser,
      settings: {
        ...editedUser.settings,
        data: {
          ...settingsData,
          [key]: value
        }
      }
    });
  };

  const handleAddNewSetting = () => {
    if (!editedUser?.settings || !newSettingKey.trim()) return;

    // Convert key to camelCase
    const camelCasedKey = toCamelCase(newSettingKey);

    let parsedValue: string | boolean | number;

    switch (newSettingType) {
      case 'boolean':
        parsedValue = newSettingValue.toLowerCase() === 'true';
        break;
      case 'number':
        parsedValue = Number(newSettingValue);
        // Return if the number is invalid
        if (isNaN(parsedValue)) {
          toast.error('Please enter a valid number');
          return;
        }
        break;
      default:
        parsedValue = newSettingValue.trim();
    }

    const settingsData = editedUser.settings.data || {};

    // Check if the setting already exists
    if (settingsData[camelCasedKey] !== undefined) {
      toast.error(`Setting "${camelCasedKey}" already exists`);
      return;
    }

    setEditedUser({
      ...editedUser,
      settings: {
        ...editedUser.settings,
        data: {
          ...settingsData,
          [camelCasedKey]: parsedValue
        }
      }
    });
    setNewSettingKey('');
    setNewSettingValue('');
    setNewSettingType('string');
    setShowNewSettingForm(false);

    // Show a toast if the key was modified
    if (camelCasedKey !== newSettingKey) {
      toast.success(`Setting key was converted to camelCase: "${camelCasedKey}"`);
    }
  };

  const handleRemoveSetting = (key: string) => {
    if (!editedUser?.settings) return;
    const settingsData = { ...(editedUser.settings.data || {}) };
    delete settingsData[key];
    setEditedUser({
      ...editedUser,
      settings: {
        ...editedUser.settings,
        data: settingsData
      }
    });
  };

  const handleSave = () => {
    if (!editedUser) return;
    updateUserMutation.mutate(editedUser);
  };

  const handleCancel = () => {
    if (!user) return;
    setEditedUser(user);
    setIsEditing(false);
    setShowNewSettingForm(false);
  };

  if (isLoading) {
    return (
      <div className="p-6 flex justify-center items-center">
        <div className="loading loading-spinner loading-lg" />
      </div>
    );
  }

  if (error || !user || !editedUser) {
    return (
      <div className="p-6 flex flex-col justify-center items-center space-y-4">
        <div className="text-error text-lg font-bold">Failed to load user</div>
        <div className="text-sm text-muted-foreground">
          {error instanceof Error ? error.message : 'Please try again later'}
        </div>
        <button
          className="btn btn-primary btn-sm"
          onClick={() => router.push('/admin/users')}
        >
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.back()}
            className="btn-circle"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-2xl font-bold">User Details</h1>
        </div>
        <div className="space-x-2">
          {isEditing ? (
            <>
              <Button
                onClick={handleSave}
                className="btn btn-primary gap-2"
                disabled={updateUserMutation.isPending}
              >
                {updateUserMutation.isPending ? (
                  <span className="loading loading-spinner loading-sm" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {updateUserMutation.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
              <Button onClick={handleCancel} className="btn btn-ghost gap-2">
                <X className="w-4 h-4" />
                Cancel
              </Button>
            </>
          ) : (
            <Button
              onClick={() => setIsEditing(true)}
              className="btn btn-primary gap-2"
            >
              <Save className="w-4 h-4" />
              Edit User
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Profile Section */}
        <section className="card bg-base-100 shadow-lg">
          <div className="card-body">
            <h2 className="card-title mb-6">Profile Information</h2>

            <div className="flex flex-col items-center gap-4 mb-8">
              <div className="avatar">
                <div className="w-24 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
                  <Image
                    alt={`${editedUser.name || "User"}'s avatar`}
                    src={editedUser.image || "/default-avatar.png"}
                    width={96}
                    height={96}
                  />
                </div>
              </div>
              {isEditing ? (
                <input
                  type="text"
                  value={editedUser.name || ''}
                  onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                  className="input input-bordered w-full"
                  placeholder="User Name"
                />
              ) : (
                <h3 className="text-xl font-bold">{user.name || 'Unnamed User'}</h3>
              )}
            </div>

            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium">Email</label>
                {isEditing ? (
                  <input
                    type="email"
                    value={editedUser.email || ''}
                    onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                    className="input input-bordered w-full mt-1"
                  />
                ) : (
                  <p className="mt-1">{user.email}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium">Role</label>
                {isEditing ? (
                  <Select
                    value={editedUser.role || 'user'}
                    onChange={(e) => setEditedUser({ ...editedUser, role: e.target.value })}
                  >
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </Select>
                ) : (
                  <p className="capitalize mt-1">{user.role || 'user'}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium">Subscription Status</label>
                {isEditing ? (
                  <Select
                    value={editedUser.subscriptionStatus || 'inactive'}
                    onChange={(e) => setEditedUser({ ...editedUser, subscriptionStatus: e.target.value })}
                  >
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </Select>
                ) : (
                  <div className="mt-1">
                    <div className={`badge ${user.subscriptionStatus === 'active' ? 'badge-success' :
                      user.subscriptionStatus === 'trial' ? 'badge-warning' : 'badge-error'}`}>
                      {user.subscriptionStatus || 'inactive'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Settings Section */}
        <section className="card bg-base-100 shadow-lg">
          <div className="card-body">
            <div className="flex justify-between items-center mb-6">
              <h2 className="card-title">User Settings</h2>
              {isEditing && (
                <button
                  onClick={() => setShowNewSettingForm(true)}
                  className="btn btn-ghost btn-sm gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Setting
                </button>
              )}
            </div>

            {showNewSettingForm && isEditing && (
              <div className="card bg-base-200 p-4 mb-6">
                <h3 className="font-medium mb-4">Add New Setting</h3>
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Setting Key (will be converted to camelCase)"
                    value={newSettingKey}
                    onChange={(e) => setNewSettingKey(e.target.value)}
                    className="input input-bordered w-full"
                  />
                  <Select
                    value={newSettingType}
                    onChange={(e) => {
                      const type = e.target.value as 'string' | 'boolean' | 'number';
                      setNewSettingType(type);
                      setNewSettingValue(type === 'boolean' ? 'true' : '');
                    }}
                  >
                    <SelectItem value="string">String</SelectItem>
                    <SelectItem value="boolean">Boolean</SelectItem>
                    <SelectItem value="number">Number</SelectItem>
                  </Select>
                  {newSettingType === 'boolean' ? (
                    <Select
                      value={newSettingValue}
                      onChange={(e) => setNewSettingValue(e.target.value)}
                    >
                      <SelectItem value="true">True</SelectItem>
                      <SelectItem value="false">False</SelectItem>
                    </Select>
                  ) : (
                    <input
                      type={newSettingType === 'number' ? 'number' : 'text'}
                      placeholder={`Setting Value (${newSettingType})`}
                      value={newSettingValue}
                      onChange={(e) => setNewSettingValue(e.target.value)}
                      className="input input-bordered w-full"
                    />
                  )}
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => {
                        setShowNewSettingForm(false);
                        setNewSettingKey('');
                        setNewSettingValue('');
                        setNewSettingType('string');
                      }}
                      className="btn btn-ghost btn-sm"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddNewSetting}
                      className="btn btn-primary btn-sm"
                      disabled={!newSettingKey.trim() || (
                        newSettingType === 'number' ? isNaN(Number(newSettingValue)) :
                          newSettingType === 'string' ? !newSettingValue.trim() : false
                      )}
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-6">
              {editedUser.settings && (() => {
                const settings = editedUser.settings.data || {};
                const entries = Object.entries(settings);
                const features = entries.filter(([key]) => key.startsWith('feature'));
                const regularSettings = entries.filter(([key]) => !key.startsWith('feature'));

                return (
                  <>
                    {/* Regular Settings */}
                    {regularSettings.length > 0 && (
                      <div className="space-y-4">
                        <h3 className="font-medium text-lg">General Settings</h3>
                        <div className="space-y-2">
                          {regularSettings.map(([key, value]) => (
                            <div key={key} className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                              <span className="font-medium capitalize">
                                {key.replace(/([A-Z])/g, ' $1').trim()}
                              </span>
                              <div className="flex items-center gap-4">
                                {isEditing ? (
                                  typeof value === 'boolean' ? (
                                    <input
                                      type="checkbox"
                                      className="toggle toggle-primary"
                                      checked={value}
                                      onChange={() => handleSettingToggle(key)}
                                    />
                                  ) : (
                                    <input
                                      type="text"
                                      value={String(value)}
                                      onChange={(e) => handleSettingChange(key, e.target.value)}
                                      className="input input-bordered input-sm w-[200px]"
                                    />
                                  )
                                ) : (
                                  <span className="text-sm">
                                    {typeof value === 'boolean' ? (
                                      <div className={`badge ${value ? 'badge-success' : 'badge-error'}`}>
                                        {value ? 'Enabled' : 'Disabled'}
                                      </div>
                                    ) : String(value)}
                                  </span>
                                )}
                                {isEditing && (
                                  <button
                                    onClick={() => handleRemoveSetting(key)}
                                    className="btn btn-ghost btn-sm btn-square"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Feature Flags */}
                    {features.length > 0 && (
                      <div className="space-y-4">
                        <div className="divider" />
                        <h3 className="font-medium text-lg">Features</h3>
                        <div className="space-y-2">
                          {features.map(([key, value]) => (
                            <div key={key} className="bg-base-200 p-4 rounded-lg flex items-center justify-between">
                              <span className="font-medium capitalize">
                                {key.replace(/feature/i, '').replace(/([A-Z])/g, ' $1').trim()}
                              </span>
                              <div className="flex items-center gap-4">
                                {isEditing ? (
                                  typeof value === 'boolean' ? (
                                    <input
                                      type="checkbox"
                                      className="toggle toggle-primary"
                                      checked={value}
                                      onChange={() => handleSettingToggle(key)}
                                    />
                                  ) : (
                                    <input
                                      type="text"
                                      value={String(value)}
                                      onChange={(e) => handleSettingChange(key, e.target.value)}
                                      className="input input-bordered input-sm w-[200px]"
                                    />
                                  )
                                ) : (
                                  <span className="text-sm">
                                    {typeof value === 'boolean' ? (
                                      <div className={`badge ${value ? 'badge-success' : 'badge-error'}`}>
                                        {value ? 'Enabled' : 'Disabled'}
                                      </div>
                                    ) : String(value)}
                                  </span>
                                )}
                                {isEditing && (
                                  <button
                                    onClick={() => handleRemoveSetting(key)}
                                    className="btn btn-ghost btn-sm btn-square"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                );
              })()}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}