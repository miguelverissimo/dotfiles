"use client";

import { Skeleton } from "@/components/ui/skeleton";
import { useDebounce } from "@/hooks/use-debounce";
import type { GetUsersResponse } from "@/lib/actions/user-actions";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Loader2, Search } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";

async function fetchUsers({ page, limit, search }: { page: number; limit: number; search: string }) {
  const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    ...(search && { search })
  });

  const response = await fetch(`/api/users?${params}`);
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to fetch users');
  }
  return response.json() as Promise<GetUsersResponse>;
}

export default function UsersPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const debouncedSearch = useDebounce(searchTerm, 300);

  const { data, isLoading, isFetching, error } = useQuery({
    queryKey: ['users', currentPage, debouncedSearch],
    queryFn: () => fetchUsers({
      page: currentPage,
      limit: 10,
      search: debouncedSearch
    })
  });

  const getStatusBadgeClass = (status: string | null) => {
    switch (status) {
      case "active":
        return "badge-success";
      case "trial":
        return "badge-warning";
      case "inactive":
        return "badge-error";
      default:
        return "badge-ghost";
    }
  };

  if (error) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="text-error text-lg font-semibold">Failed to load users</div>
        <div className="text-sm text-base-content/70">
          {error instanceof Error ? error.message : 'Please try again later'}
        </div>
        <button
          className="btn btn-primary btn-sm"
          onClick={() => window.location.reload()}
        >
          Retry
        </button>
      </div>
    );
  }

  const showLoadingState = isLoading || (isFetching && debouncedSearch !== '');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Users</h1>
        <div className="join relative">
          <div className="join-item relative">
            <Search className="absolute left-3 top-3 w-5 h-5 pointer-events-none opacity-50" />
            {isFetching && (
              <Loader2 className="absolute right-3 top-3 w-5 h-5 animate-spin opacity-70" />
            )}
            <input
              type="text"
              placeholder="Search by email or name..."
              className="input input-bordered pl-10 pr-10 w-full max-w-xs"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1); // Reset to first page on search
              }}
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto relative">
        {isFetching && !isLoading && (
          <div className="absolute inset-0 bg-base-100/50 backdrop-blur-[1px] z-10 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin opacity-70" />
          </div>
        )}
        <table className="table">
          <thead>
            <tr>
              <th>User</th>
              <th>Email</th>
              <th>Subscription Status</th>
            </tr>
          </thead>
          <tbody className={isFetching && !isLoading ? 'opacity-50' : ''}>
            {showLoadingState ? (
              Array.from({ length: 10 }).map((_, index) => (
                <tr key={index}>
                  <td>
                    <div className="flex items-center gap-3">
                      <Skeleton className="w-12 h-12 rounded-full" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </td>
                  <td><Skeleton className="h-4 w-48" /></td>
                  <td><Skeleton className="h-4 w-24" /></td>
                </tr>
              ))
            ) : (
              data?.users.map((user) => (
                <tr
                  key={user.id}
                  className="hover:bg-base-200 cursor-pointer"
                  onClick={() => router.push(`/admin/users/${user.id}`)}
                >
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="avatar">
                        <div className="w-12 h-12 rounded-full">
                          <Image
                            alt={`${user.name || "User"}'s avatar`}
                            src={user.image || "/default-avatar.png"}
                            width={84}
                            height={84}
                          />
                        </div>
                      </div>
                      <span>{user.name || 'Unnamed User'}</span>
                    </div>
                  </td>
                  <td>{user.email}</td>
                  <td>
                    <div className={`badge ${getStatusBadgeClass(user.subscriptionStatus)}`}>
                      {user.subscriptionStatus || 'no subscription'}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex justify-center gap-2">
        <button
          className="btn btn-circle btn-sm"
          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
          disabled={currentPage === 1 || showLoadingState}
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="flex items-center gap-1">
          Page {currentPage} of {data?.totalPages || 1}
        </span>
        <button
          className="btn btn-circle btn-sm"
          onClick={() => setCurrentPage(p => Math.min(data?.totalPages || 1, p + 1))}
          disabled={currentPage === (data?.totalPages || 1) || showLoadingState}
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}