import { dirname } from "path";
import { fileURLToPath } from "url";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
  recommendedConfig: {
    extends: ["eslint:recommended", "next/core-web-vitals", "next/typescript"],
    "plugins": ["boundaries"],
    "settings": {
      "boundaries/include": ["src/**/*"],
      "boundaries/elements": [
        {
          "mode": "full",
          "type": "shared",
          "pattern": [
            "src/schemas/**/*",
            "src/hooks/**/*",
            "src/stores/**/*",
            "src/utils/**/*",
            "src/schemas/**/*",
            "src/components/**/*",
            "src/providers/**/*",
            "src/lib/**/*",
            "src/types/**/*"
          ]
        },
        {
          "mode": "full",
          "type": "feature",
          "capture": ["feature-name"],
          "pattern": ["src/features/*/**/*"]
        },
        {
          "mode": "full",
          "type": "app",
          "capture": ["_", "file-name"],
          "pattern": ["src/app/**/*"]
        },
        {
          "mode": "full",
          "type": "neverImport",
          "pattern": ["src/*", "src/tasks/**/*"]
        }
      ]
    },
    "rules": {
      "boundaries/no-unknown": ["error"],
      "boundaries/no-unknown-files": ["error"],
      "boundaries/element-types": [
        "error",
        {
          "default": "disallow",
          "rules": [
            {
              "from": ["shared"],
              "allow": ["shared"]
            },
            {
              "from": ["feature"],
              "allow": [
                "shared",
                ["feature", { "featureName": "${from.featureName}" }]
              ]
            },
            {
              "from": ["app", "neverImport"],
              "allow": ["shared", "feature"]
            },
            {
              "from": ["app"],
              "allow": [["app", { "fileName": "*.css" }]]
            }
          ]
        }
      ]
    }
  }
});

const eslintConfig = [
  ...compat.extends("next/core-web-vitals", "next/typescript"),
];

export default eslintConfig;
